import { useEffect, useState } from 'react';
import {
  PROJECTS,
  type LanguageCode,
  type ProjectCaseStudy,
  type ProjectCategory,
  type ServiceItem,
  type UpcomingExhibition,
} from './data/content';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { SelectedWork } from './components/SelectedWork';
import { CaseStudyView } from './components/CaseStudyView';
import { ServicesSection } from './components/ServicesSection';
import { ProcessSection } from './components/ProcessSection';
import { WhyProspectSection } from './components/WhyProspectSection';
import { ClientsMarquee } from './components/ClientsMarquee';
import { TestimonialsSlider } from './components/TestimonialsSlider';
import { VideoTourSection } from './components/VideoTourSection';
import { UpcomingExhibitions } from './components/UpcomingExhibitions';
import { FaqAccordion } from './components/FaqAccordion';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingContactBar } from './components/FloatingContactBar';

function getProjectFromHash(): ProjectCaseStudy | null {
  if (typeof window === 'undefined') return null;
  const hash = window.location.hash;
  if (!hash.startsWith('#project/')) return null;
  const slug = hash.replace('#project/', '').trim();
  return PROJECTS.find((p) => p.slug === slug) ?? null;
}

export default function App() {
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('All');
  const [activeProject, setActiveProject] = useState<ProjectCaseStudy | null>(() =>
    getProjectFromHash()
  );
  const [contactPrefill, setContactPrefill] = useState<{
    requirement?: string;
    message?: string;
  }>({});

  // Sync browser back/forward navigation with case study deep links
  useEffect(() => {
    const handleHashChange = () => {
      setActiveProject(getProjectFromHash());
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const scrollToSection = (sectionId?: string) => {
    if (!sectionId) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleNavigateHome = (sectionId?: string) => {
    const wasInCaseStudy = Boolean(activeProject);
    if (wasInCaseStudy) {
      setActiveProject(null);
      if (window.location.hash.startsWith('#project/')) {
        window.history.pushState(null, '', sectionId ? `#${sectionId}` : '#top');
      }
      requestAnimationFrame(() => {
        setTimeout(() => scrollToSection(sectionId), 40);
      });
    } else {
      scrollToSection(sectionId);
    }
  };

  const handleSelectProject = (project: ProjectCaseStudy) => {
    setActiveProject(project);
    window.history.pushState(null, '', `#project/${project.slug}`);
  };

  const handleBackToWork = () => {
    setActiveProject(null);
    window.history.pushState(null, '', '#work');
    requestAnimationFrame(() => {
      setTimeout(() => scrollToSection('work'), 40);
    });
  };

  const handleRequestQuote = (requirement?: string, message?: string) => {
    if (requirement || message) {
      setContactPrefill({ requirement, message });
    }
    handleNavigateHome('contact');
  };

  const handleExploreService = (service: ServiceItem) => {
    handleRequestQuote(
      service.requirementOption,
      `Interested in ${service.title}. Please share portfolio samples and a design proposal.`
    );
  };

  const handleFilterByService = (category: Exclude<ProjectCategory, 'All'>) => {
    setActiveCategory(category);
    handleNavigateHome('work');
  };

  const handleEnquireSimilar = (project: ProjectCaseStudy) => {
    const requirementMap: Record<ProjectCaseStudy['category'], string> = {
      Exhibition: 'Exhibition Stall Design & Fabrication',
      Event: 'Corporate Event & Stage Setup',
      Activation: 'Spaces & Brand Activation',
      Interior: 'Corporate & Commercial Interior Design',
    };
    handleRequestQuote(
      requirementMap[project.category],
      `Looking for a ${project.category.toLowerCase()} concept similar to "${project.title}" (${project.area}).`
    );
  };

  const handleReserveExhibition = (expo: UpcomingExhibition) => {
    const isIntl = expo.country !== 'India';
    handleRequestQuote(
      isIntl
        ? 'International Pavilion (Germany / Dubai)'
        : 'Exhibition Stall Design & Fabrication',
      `We are exhibiting at ${expo.name} (${expo.dates}, ${expo.city}) and need a 3D stall design & turnkey fabrication quote.`
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#0E0E0E]">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:rounded-lg focus:bg-[#EA4C18] focus:text-white focus:text-sm focus:font-semibold"
      >
        Skip to main content
      </a>

      <Header
        language={language}
        onLanguageChange={setLanguage}
        onNavigateHome={handleNavigateHome}
        onRequestQuote={() => handleRequestQuote()}
        isCaseStudyOpen={Boolean(activeProject)}
      />

      <main id="main-content" className="flex-1">
        {activeProject ? (
          <CaseStudyView
            project={activeProject}
            onBack={handleBackToWork}
            onSelectProject={handleSelectProject}
            onEnquireSimilar={handleEnquireSimilar}
          />
        ) : (
          <>
            <Hero
              language={language}
              onViewWork={() => scrollToSection('work')}
              onConsultation={() =>
                handleRequestQuote(
                  'Exhibition Stall Design & Fabrication',
                  'Requesting a free 3D design consultation for our upcoming project.'
                )
              }
            />

            <SelectedWork
              language={language}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
              onSelectProject={handleSelectProject}
            />

            <ServicesSection
              language={language}
              onExploreService={handleExploreService}
              onFilterByService={handleFilterByService}
            />

            <ProcessSection language={language} />

            <WhyProspectSection language={language} />

            <ClientsMarquee language={language} />

            <TestimonialsSlider language={language} />

            <VideoTourSection language={language} />

            <UpcomingExhibitions
              language={language}
              onReserveExhibition={handleReserveExhibition}
            />

            <FaqAccordion language={language} />

            <ContactSection
              language={language}
              prefilledRequirement={contactPrefill.requirement}
              prefilledMessage={contactPrefill.message}
            />
          </>
        )}
      </main>

      <Footer onNavigateHome={handleNavigateHome} />

      <FloatingContactBar />
    </div>
  );
}
