export type ProjectCategory = 'All' | 'Exhibition' | 'Event' | 'Interior' | 'Activation';

export type LanguageCode = 'en' | 'hi' | 'mr';

export interface ProjectGalleryItem {
  src: string;
  alt: string;
  caption: string;
  width: number;
  height: number;
}

export interface ProjectCaseStudy {
  slug: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'All'>;
  industry: string;
  location: string;
  year: string;
  area: string;
  featuredSpan: 'wide' | 'tall' | 'standard';
  coverImage: string;
  coverAlt: string;
  width: number;
  height: number;
  summary: string;
  brief: string;
  challenge: string;
  solution: string;
  results: { label: string; value: string }[];
  gallery: ProjectGalleryItem[];
}

export interface ServiceItem {
  id: string;
  number: string;
  navAnchor: string;
  title: string;
  subtitle: string;
  categoryFilter: Exclude<ProjectCategory, 'All'>;
  requirementOption: string;
  image: string;
  imageAlt: string;
  bullets: string[];
}

export interface ProcessStep {
  step: string;
  title: string;
  duration: string;
  description: string;
}

export interface WhyProspectItem {
  id: string;
  title: string;
  description: string;
  icon: 'compass' | 'shield' | 'message' | 'target' | 'clock' | 'wallet';
}

export interface StatItem {
  value: number;
  suffix: string;
  label: string;
  detail: string;
}

export interface ClientLogoItem {
  name: string;
  sector: string;
  accent: string;
  monogram: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  industry: string;
  outcome: string;
}

export interface UpcomingExhibition {
  id: string;
  name: string;
  dates: string;
  city: string;
  country: string;
  sector: string;
  slotsOpen: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

/**
 * Swap any path below with your real project photography (WebP/AVIF/JPG)
 * stored under /public/projects/ or /src/assets/images/.
 */
export const MEDIA_ASSETS = {
  logo: '/assets/aistudio/image_546e1c60.png',
  // Drop your compressed <3MB hero MP4/WebM files at /public/videos/hero-showreel.mp4 & .webm
  heroVideoMp4: '',
  heroVideoWebm: '',
  heroPoster: '/src/assets/images/hero_exhibition_pavilion_1795228319111.jpg',
  exhibitionDoubleDecker: '/src/assets/images/hero_exhibition_pavilion_1795228319111.jpg',
  exhibitionPharmaDubai: '/src/assets/images/stand_pharma_dubai_1795228396014.jpg',
  exhibitionEngineeringGermany: '/src/assets/images/stand_engineering_germany_1795228332446.jpg',
  eventCorporateSummit: '/src/assets/images/event_corporate_summit_1795228322631.jpg',
  activationExperiential: '/src/assets/images/activation_experiential_space_1795228320895.jpg',
  interiorCorporateHq: '/src/assets/images/interior_turnkey_hq_1795228322775.jpg',
} as const;

export const CONTACT_INFO = {
  companyLegal: 'Prospect Exhibition Stand Designs',
  brandName: 'Prospect Designs',
  tagline: 'We Turn Ideas Into Eye-Catching Designs.',
  address: 'A103 Rao Colony, Talegaon Dabhade, Pune, Maharashtra 410506',
  phones: [
    { display: '+91 93259 93399', href: 'tel:+919325993399', raw: '919325993399' },
    { display: '+91 98608 28616', href: 'tel:+919860828616', raw: '919860828616' },
  ],
  emails: [
    { display: 'info@prospectdesigns.in', href: 'mailto:info@prospectdesigns.in' },
    { display: 'marketing@prospectdesigns.in', href: 'mailto:marketing@prospectdesigns.in' },
  ],
  whatsappNumber: '919325993399',
  whatsappBaseUrl: 'https://wa.me/919325993399',
  youtubeHandle: '@prospectdesignsindia',
  youtubeUrl: 'https://www.youtube.com/@prospectdesignsindia',
  youtubeTourId: '4BiXSeJWOcI',
  linkedinUrl: 'https://www.linkedin.com/company/prospect-designs',
  mapEmbedUrl:
    'https://maps.google.com/maps?q=A103+Rao+Colony+Talegaon+Dabhade+Pune+Maharashtra+410506&t=&z=14&ie=UTF8&iwloc=&output=embed',
  mapDirectionsUrl:
    'https://www.google.com/maps/search/?api=1&query=A103+Rao+Colony+Talegaon+Dabhade+Pune+Maharashtra+410506',
} as const;

export const UI_COPY: Record<
  LanguageCode,
  {
    nav: {
      exhibition: string;
      events: string;
      spaces: string;
      interiors: string;
      projects: string;
      about: string;
      contact: string;
      getQuote: string;
    };
    hero: {
      headline: string;
      subtext: string;
      primaryCta: string;
      secondaryCta: string;
      trustRow: string[];
    };
    sections: {
      workEyebrow: string;
      workTitle: string;
      workSub: string;
      servicesEyebrow: string;
      servicesTitle: string;
      processEyebrow: string;
      processTitle: string;
      whyEyebrow: string;
      whyTitle: string;
      clientsEyebrow: string;
      testimonialsEyebrow: string;
      testimonialsTitle: string;
      videoEyebrow: string;
      videoTitle: string;
      upcomingEyebrow: string;
      upcomingTitle: string;
      faqEyebrow: string;
      faqTitle: string;
      contactEyebrow: string;
      contactTitle: string;
    };
  }
> = {
  en: {
    nav: {
      exhibition: 'Exhibition',
      events: 'Events',
      spaces: 'Spaces',
      interiors: 'Interiors',
      projects: 'Projects',
      about: 'About',
      contact: 'Contact',
      getQuote: 'Get a Quote',
    },
    hero: {
      headline: 'Transforming Ideas Into Compelling Designs',
      subtext:
        'Turnkey exhibition stands, corporate events, brand activations, and commercial interiors built with architectural precision from Pune to global trade floors.',
      primaryCta: 'View Our Work',
      secondaryCta: 'Get a Free Design Consultation',
      trustRow: ['10+ years', '500+ projects', 'Germany & Dubai'],
    },
    sections: {
      workEyebrow: 'Selected Work',
      workTitle: 'Spaces engineered to draw footfall and close B2B deals.',
      workSub:
        'Explore custom exhibition pavilions, corporate launches, activations, and interiors delivered across India, Germany, and Dubai.',
      servicesEyebrow: '360° Capabilities',
      servicesTitle: 'One accountable partner from 3D concept to final dismantle.',
      processEyebrow: 'Execution Process',
      processTitle: 'Five disciplined stages. Zero exhibition-day surprises.',
      whyEyebrow: 'Why Prospect Designs',
      whyTitle: 'Built for marketing heads who need reliability on tight show timelines.',
      clientsEyebrow: 'Trusted by Industrial & Enterprise Leaders',
      testimonialsEyebrow: 'Client Voices',
      testimonialsTitle: 'Proven on high-stakes trade show floors.',
      videoEyebrow: 'Behind The Build',
      videoTitle: 'See how our stands come alive on the show floor.',
      upcomingEyebrow: 'Upcoming Presence',
      upcomingTitle: 'Exhibiting soon? Reserve your 3D stall design slot.',
      faqEyebrow: 'Common Questions',
      faqTitle: 'Straight answers before you brief your next show.',
      contactEyebrow: 'Start a Project',
      contactTitle: 'Share your floor plan. Receive a 3D concept proposal.',
    },
  },
  hi: {
    nav: {
      exhibition: 'प्रदर्शनी',
      events: 'इवेंट्स',
      spaces: 'स्पेसेस',
      interiors: 'इंटीरियर्स',
      projects: 'प्रोजेक्ट्स',
      about: 'हमारे बारे में',
      contact: 'संपर्क',
      getQuote: 'कोट प्राप्त करें',
    },
    hero: {
      headline: 'विचारों को आकर्षक डिज़ाइन में बदलना',
      subtext:
        'पुणे से भारत, जर्मनी और दुबई तक कस्टम प्रदर्शनी स्टॉल, कॉर्पोरेट इवेंट्स, ब्रांड एक्टिवेशन और टर्नकी इंटीरियर डिज़ाइन।',
      primaryCta: 'हमारा काम देखें',
      secondaryCta: 'मुफ़्त डिज़ाइन परामर्श लें',
      trustRow: ['10+ वर्ष अनुभव', '500+ प्रोजेक्ट्स', 'जर्मनी और दुबई'],
    },
    sections: {
      workEyebrow: 'प्रमुख प्रोजेक्ट्स',
      workTitle: 'ऐसे स्टॉल और स्पेस जो विज़िटर्स को आकर्षित करें और व्यवसाय बढ़ाएं।',
      workSub:
        'भारत, जर्मनी और दुबई में निर्मित कस्टम प्रदर्शनी पवेलियन, कॉर्पोरेट इवेंट्स और इंटीरियर्स देखें।',
      servicesEyebrow: '360° सेवाएं',
      servicesTitle: '3D डिज़ाइन से लेकर फाइनल इंस्टॉलेशन तक एक विश्वसनीय पार्टनर।',
      processEyebrow: 'कार्य प्रक्रिया',
      processTitle: 'पांच स्पष्ट चरण। समय पर सटीक डिलीवरी।',
      whyEyebrow: 'प्रॉस्पेक्ट डिज़ाइन्स क्यों',
      whyTitle: 'समयबद्ध और उच्च गुणवत्ता वाले प्रदर्शन के लिए समर्पित।',
      clientsEyebrow: 'अग्रणी औद्योगिक कंपनियों का विश्वास',
      testimonialsEyebrow: 'ग्राहक अनुभव',
      testimonialsTitle: 'प्रदर्शनी फ्लोर पर सिद्ध परिणाम।',
      videoEyebrow: 'वीडियो टूर',
      videoTitle: 'देखें हमारे स्टॉल प्रदर्शनी में कैसे जीवंत होते हैं।',
      upcomingEyebrow: 'आगामी प्रदर्शनियाँ',
      upcomingTitle: 'आगामी ट्रेड शो के लिए अपना 3D स्टॉल स्लॉट बुक करें।',
      faqEyebrow: 'सामान्य प्रश्न',
      faqTitle: 'प्रोजेक्ट शुरू करने से पहले आवश्यक जानकारी।',
      contactEyebrow: 'प्रोजेक्ट शुरू करें',
      contactTitle: 'अपना फ्लोर प्लान साझा करें और 3D प्रस्ताव प्राप्त करें।',
    },
  },
  mr: {
    nav: {
      exhibition: 'प्रदर्शन स्टॉल',
      events: 'इव्हेंट्स',
      spaces: 'स्पेसेस',
      interiors: 'इंटिरियर्स',
      projects: 'प्रकल्प',
      about: 'आमच्याबद्दल',
      contact: 'संपर्क',
      getQuote: 'कोटेशन मिळवा',
    },
    hero: {
      headline: 'कल्पनांचे प्रभावी डिझाइनमध्ये रूपांतर',
      subtext:
        'तळेगाव दाभाडे, पुणे येथून भारत, जर्मनी आणि दुबईसाठी कस्टम प्रदर्शन स्टॉल, कॉर्पोरेट इव्हेंट्स, ब्रँड अ‍ॅक्टिव्हेशन आणि इंटिरियर डिझाइन.',
      primaryCta: 'आमचे काम पहा',
      secondaryCta: 'मोफत डिझाइन सल्ला घ्या',
      trustRow: ['10+ वर्षे अनुभव', '500+ प्रकल्प', 'जर्मनी आणि दुबई'],
    },
    sections: {
      workEyebrow: 'निवडक प्रकल्प',
      workTitle: 'ग्राहकांचे लक्ष वेधणारे आणि व्यवसाय वाढवणारे डिझाइन.',
      workSub:
        'भारत, जर्मनी आणि दुबईमधील आमचे कस्टम प्रदर्शन स्टॉल, इव्हेंट्स आणि कॉर्पोरेट इंटिरियर्स पहा.',
      servicesEyebrow: '360° सेवा',
      servicesTitle: '3D संकल्पनेपासून प्रत्यक्ष उभारणीपर्यंत संपूर्ण जबाबदारी.',
      processEyebrow: 'कार्यपद्धती',
      processTitle: 'पाच शिस्तबद्ध टप्पे. वेळेवर आणि अचूक पूर्णता.',
      whyEyebrow: 'प्रॉस्पेक्ट डिझाइन्स का निवडावे',
      whyTitle: 'वेळेची मर्यादा आणि दर्जेदार कामासाठी विश्वासार्ह भागीदार.',
      clientsEyebrow: 'नामांकित औद्योगिक ग्राहकांचा विश्वास',
      testimonialsEyebrow: 'ग्राहक अभिप्राय',
      testimonialsTitle: 'आंतरराष्ट्रीय प्रदर्शनांमध्ये सिद्ध गुणवत्ता.',
      videoEyebrow: 'व्हिडिओ टूर',
      videoTitle: 'आमचे स्टॉल प्रदर्शनामध्ये कसे साकार होतात ते पहा.',
      upcomingEyebrow: 'आगामी प्रदर्शने',
      upcomingTitle: 'आगामी प्रदर्शनासाठी आजच 3D स्टॉल डिझाइन बुक करा.',
      faqEyebrow: 'नेहमीचे प्रश्न',
      faqTitle: 'तुमच्या पुढील प्रकल्पासाठी स्पष्ट उत्तरे.',
      contactEyebrow: 'प्रकल्प सुरू करा',
      contactTitle: 'तुमचा फ्लोअर प्लॅन पाठवा आणि 3D डिझाइन प्रस्ताव मिळवा.',
    },
  },
};

export const PROJECTS: ProjectCaseStudy[] = [
  {
    slug: 'quantum-automation-double-decker',
    title: 'Double-Decker Industrial Automation Pavilion',
    client: 'Quantum Advance Automation',
    category: 'Exhibition',
    industry: 'Electronics & Robotics',
    location: 'Hannover, Germany',
    year: '2026',
    area: '144 sq.m (2-Level)',
    featuredSpan: 'wide',
    coverImage: MEDIA_ASSETS.exhibitionDoubleDecker,
    coverAlt:
      'Double-decker white geometric industrial exhibition stand with mezzanine glass lounge and warm orange linear architectural lighting',
    width: 1600,
    height: 900,
    summary:
      'Sculpted matte-white two-tier pavilion featuring a sound-insulated executive mezzanine lounge and six illuminated live robotics demo bays.',
    brief:
      'Showcase heavy mechatronics and live robotic drive units on an open four-side island plot while reserving private acoustic space for OEM contract negotiations.',
    challenge:
      'Strict German trade fair structural load certifications and a compressed 72-hour build window demanded pre-engineered modular steel framing with zero on-site cutting.',
    solution:
      'We engineered a pre-fitted angular white canopy with embedded warm LED architectural lines, pairing open-floor machinery plinths below with a cantilevered glass VIP suite above.',
    results: [
      { label: 'Qualified B2B Leads', value: '+168%' },
      { label: 'On-Site Build Time', value: '64 hrs' },
      { label: 'Executive Meetings Hosted', value: '94' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.exhibitionDoubleDecker,
        alt: 'Full perspective of the double-decker automation pavilion at the international hall',
        caption: 'Corner elevation with warm architectural LED fascia and live machinery zone',
        width: 1600,
        height: 900,
      },
      {
        src: MEDIA_ASSETS.exhibitionEngineeringGermany,
        alt: 'Precision tooling and industrial demo pedestals inside an open-island stand',
        caption: 'Dedicated product demonstration plinths engineered for heavy industrial components',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.exhibitionPharmaDubai,
        alt: 'Acoustic glass meeting lounge detail for private B2B consultations',
        caption: 'Acoustic glazing and warm oak hospitality reception detailing',
        width: 1400,
        height: 1050,
      },
    ],
  },
  {
    slug: 'kalyani-die-mould-munich',
    title: 'Precision Die & Mould Island Stand',
    client: 'Kalyani Tooling Systems',
    category: 'Exhibition',
    industry: 'Die & Mould / Manufacturing',
    location: 'Stuttgart & Pune (IMTEX)',
    year: '2026',
    area: '96 sq.m',
    featuredSpan: 'standard',
    coverImage: MEDIA_ASSETS.exhibitionEngineeringGermany,
    coverAlt:
      'Open-island precision engineering and die and mould exhibition stand with vermilion orange fascia beam and warm timber slats',
    width: 1400,
    height: 1050,
    summary:
      'High-visibility 4-side open island pavilion combining matte charcoal portals, vertical timber slats, and reinforced steel plinths for multi-ton tooling moulds.',
    brief:
      'Position an Indian precision die-and-mould exporter alongside European Tier-1 suppliers with unmistakable brand visibility from three hall aisles away.',
    challenge:
      'Heavy steel moulds exceeding 850 kg per unit required concealed structural floor load distribution while maintaining an airy, refined gallery aesthetic.',
    solution:
      'Built a continuous vermilion overhead fascia beam framing matte-dark portals, suspended high-CRI track spots, and custom steel-core pedestals clad in architectural laminate.',
    results: [
      { label: 'Aisle Visibility Range', value: '65 m' },
      { label: 'Export RFQs Captured', value: '140+' },
      { label: 'Reusable Kit Rate', value: '82%' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.exhibitionEngineeringGermany,
        alt: 'Precision Engineering and Tooling open-island stand with illuminated mould pedestals',
        caption: 'High-contrast vermilion fascia and CNC tooling display showcase',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.exhibitionDoubleDecker,
        alt: 'Wide hall view of industrial machinery presentation layout',
        caption: 'Traffic-flow zoning separating walk-in demos from seated technical discussions',
        width: 1600,
        height: 900,
      },
      {
        src: MEDIA_ASSETS.interiorCorporateHq,
        alt: 'Architectural fluted wood and charcoal steel material finish reference',
        caption: 'Material palette carried consistently into client headquarters showroom',
        width: 1400,
        height: 1050,
      },
    ],
  },
  {
    slug: 'pharmavue-dubai-pavilion',
    title: 'Cleanroom-Inspired Pharma Pavilion',
    client: 'PharmaVue Life Sciences',
    category: 'Exhibition',
    industry: 'Pharmaceuticals',
    location: 'Dubai World Trade Centre',
    year: '2025',
    area: '84 sq.m',
    featuredSpan: 'standard',
    coverImage: MEDIA_ASSETS.exhibitionPharmaDubai,
    coverAlt:
      'Minimalist white pharmaceutical exhibition pavilion in Dubai with suspended glowing ring canopies and glass meeting rooms',
    width: 1400,
    height: 1050,
    summary:
      'Crisp fluted white architecture with dual suspended halo luminaires and two acoustic glass regulatory briefing suites for Arab Health & CPHI.',
    brief:
      'Communicate clinical precision and EU-GMP reliability while offering quiet, enclosed meeting suites for international hospital and distributor buyers.',
    challenge:
      'Balancing open approachability from the main concourse with confidential pharma licensing discussions in a bustling Dubai hall.',
    solution:
      'Paired full-height fluted white walls and transparent acoustic glass pods with warm natural oak hospitality counters and floating circular light canopies.',
    results: [
      { label: 'Distributor Sign-Ups', value: '38' },
      { label: 'Handover Lead Time', value: '14 hrs early' },
      { label: 'Client Satisfaction', value: '10/10' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.exhibitionPharmaDubai,
        alt: 'Minimalist white ribbed pharmaceutical booth with ring lighting in Dubai',
        caption: 'Suspended halo luminaires and acoustic glass meeting pods',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.activationExperiential,
        alt: 'Open hospitality and digital engagement counter detail',
        caption: 'Interactive digital portfolio station for technical specification walk-throughs',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.exhibitionDoubleDecker,
        alt: 'Executive consultation space with warm indirect illumination',
        caption: 'Warm architectural lighting calibrated for long exhibition days',
        width: 1600,
        height: 900,
      },
    ],
  },
  {
    slug: 'bharat-industrial-summit-pune',
    title: 'Annual Manufacturing Leadership Summit',
    client: 'Sahyadri Industrial Group',
    category: 'Event',
    industry: 'Manufacturing & Textile',
    location: 'Pune, India',
    year: '2026',
    area: '650-Seat Auditorium',
    featuredSpan: 'standard',
    coverImage: MEDIA_ASSETS.eventCorporateSummit,
    coverAlt:
      'Wide curved panoramic LED stage backdrop in dark charcoal and warm amber light beams for a corporate B2B summit',
    width: 1400,
    height: 1050,
    summary:
      'Turnkey 18-metre panoramic curved LED stage architecture, synchronized lighting plot, executive keynote production, and pre-function exhibition foyer.',
    brief:
      'Deliver a flagship annual dealer and OEM partner convention for 600+ industrial delegates with seamless live product unveilings and zero AV downtime.',
    challenge:
      'Transforming a heritage convention auditorium overnight with custom curved rigging, line-array acoustics, and multi-camera live broadcast switching.',
    solution:
      'Designed an architectural 2.6mm pitch curved LED canvas paired with linear overhead wash fixtures, custom minimalist lectern, and cohesive branded wayfinding.',
    results: [
      { label: 'Delegates Attended', value: '640' },
      { label: 'AV & Cue Accuracy', value: '100%' },
      { label: 'Setup Turnaround', value: '18 hrs' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.eventCorporateSummit,
        alt: 'Curved panoramic LED stage backdrop with warm architectural lighting at B2B summit',
        caption: '18-metre curved LED stage with synchronized geometric keynote visuals',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.activationExperiential,
        alt: 'Pre-function atrium brand activation zone for summit delegates',
        caption: 'Pre-function experiential atrium lounge and product discovery stations',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.interiorCorporateHq,
        alt: 'VIP speaker holding lounge and executive briefing area',
        caption: 'Dedicated VIP speaker lounge and press briefing suite',
        width: 1400,
        height: 1050,
      },
    ],
  },
  {
    slug: 'verve-experiential-atrium-pavilion',
    title: 'Modular Timber & Steel Brand Activation',
    client: 'Verve Smart Electronics',
    category: 'Activation',
    industry: 'Electronics & Consumer Tech',
    location: 'Mumbai & Bengaluru',
    year: '2025',
    area: '110 sq.m Multi-City',
    featuredSpan: 'standard',
    coverImage: MEDIA_ASSETS.activationExperiential,
    coverAlt:
      'Sculptural cantilevered timber and brushed steel brand activation pavilion inside a sunlit corporate atrium',
    width: 1400,
    height: 1050,
    summary:
      'Multi-city demountable architectural timber-and-steel archway pavilion with backlit interactive demo tables for enterprise tech park activations.',
    brief:
      'Create an architectural brand installation that installs inside Grade-A corporate atriums in under 8 hours and travels smoothly across four Indian metros.',
    challenge:
      'Strict building-management constraints barred floor bolting, heavy cranes, or noisy assembly while requiring landmark visual presence.',
    solution:
      'Engineered self-ballasted brushed-steel anchor bases supporting precision CNC-milled timber ribs with plug-and-play illuminated product counters.',
    results: [
      { label: 'Cities Deployed', value: '4 Metros' },
      { label: 'Avg. Dwell Time', value: '6.4 min' },
      { label: 'Overnight Install', value: '7.5 hrs' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.activationExperiential,
        alt: 'Cantilevered wood and steel brand activation pavilion in glass atrium',
        caption: 'CNC-milled modular timber ribs with integrated brushed-steel bases',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.exhibitionEngineeringGermany,
        alt: 'Interactive product counter and illuminated showcase detail',
        caption: 'Plug-and-play backlit showcase tables for rapid multi-city turnaround',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.eventCorporateSummit,
        alt: 'Evening launch presentation integrated with the activation campaign',
        caption: 'Companion keynote launch environment',
        width: 1400,
        height: 1050,
      },
    ],
  },
  {
    slug: 'chakan-engineering-hq-interiors',
    title: 'Corporate HQ & Industrial Experience Centre',
    client: 'Deccan Precision Drives',
    category: 'Interior',
    industry: 'Automotive & Manufacturing',
    location: 'Chakan & Talegaon, Pune',
    year: '2026',
    area: '6,800 sq.ft',
    featuredSpan: 'wide',
    coverImage: MEDIA_ASSETS.interiorCorporateHq,
    coverAlt:
      'Contemporary double-height corporate headquarters reception in Pune with fluted oak cladding, acoustic glass mezzanine, and sculptural reception desk',
    width: 1400,
    height: 1050,
    summary:
      'Double-height corporate lobby, cantilevered glass boardroom, and permanent customer experience gallery built turnkey in 75 days.',
    brief:
      'Transform a raw industrial administrative block in Pune’s Chakan-Talegaon belt into an executive headquarters worthy of visiting European OEM auditors.',
    challenge:
      'Unifying exposed factory structural steel and double-height glazing with warm executive hospitality and whisper-quiet meeting room acoustics.',
    solution:
      'Introduced full-height fluted oak acoustic wall cladding, a structural mezzanine glass conference pod, terrazzo flooring, and a monolithic concrete-and-timber reception counter.',
    results: [
      { label: 'Turnkey Delivery', value: '75 days' },
      { label: 'Floor Area Built', value: '6,800 sq.ft' },
      { label: 'Budget Variance', value: '0%' },
    ],
    gallery: [
      {
        src: MEDIA_ASSETS.interiorCorporateHq,
        alt: 'Double-height corporate headquarters reception with fluted oak walls and glass mezzanine',
        caption: 'Double-height reception atrium and suspended executive boardroom',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.exhibitionPharmaDubai,
        alt: 'Acoustic glass meeting pod and warm timber hospitality zone',
        caption: 'Client audit briefing suites with acoustic double glazing',
        width: 1400,
        height: 1050,
      },
      {
        src: MEDIA_ASSETS.activationExperiential,
        alt: 'Permanent product experience gallery detail',
        caption: 'Integrated customer experience centre displaying flagship assemblies',
        width: 1400,
        height: 1050,
      },
    ],
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'exhibition',
    number: '01',
    navAnchor: 'exhibition',
    title: 'Exhibition Stalls',
    subtitle: 'Custom, modular, and double-decker stands built for domestic and international trade shows.',
    categoryFilter: 'Exhibition',
    requirementOption: 'Exhibition Stall Design & Fabrication',
    image: MEDIA_ASSETS.exhibitionEngineeringGermany,
    imageAlt: 'Custom open-island exhibition stall designed and fabricated by Prospect Designs',
    bullets: [
      'Photorealistic 3D architectural concepts within 48 hours of brief',
      'In-house Pune fabrication workshop ensuring tight finish control',
      'End-to-end execution across India, Germany, and Dubai venues',
      'Custom, octanorm-hybrid, mezzanine, and reusable country pavilions',
      'Complete graphics, AV integration, lighting, and show-floor supervision',
    ],
  },
  {
    id: 'events',
    number: '02',
    navAnchor: 'events',
    title: 'Events Organisation',
    subtitle: 'High-impact corporate summits, dealer meets, and B2B product launches engineered to run on cue.',
    categoryFilter: 'Event',
    requirementOption: 'Corporate Event & Stage Setup',
    image: MEDIA_ASSETS.eventCorporateSummit,
    imageAlt: 'Corporate summit auditorium with curved LED backdrop and architectural stage lighting',
    bullets: [
      'Bespoke stage architecture, curved LED walls, and thematic backdrops',
      'Concert-grade audio, synchronized lighting plots, and live switching',
      'Dealer conferences, annual galas, factory inaugurations, and town halls',
      'Delegate registration zones, wayfinding signage, and VIP hospitality',
      'Single dedicated show producer from venue recce to pack-up',
    ],
  },
  {
    id: 'spaces',
    number: '03',
    navAnchor: 'spaces',
    title: 'Spaces & Brand Activation',
    subtitle: 'Tactile pop-up pavilions, roadshows, and experiential zones that turn footfall into conversation.',
    categoryFilter: 'Activation',
    requirementOption: 'Spaces & Brand Activation',
    image: MEDIA_ASSETS.activationExperiential,
    imageAlt: 'Modular timber and brushed steel experiential brand activation pavilion in a sunlit atrium',
    bullets: [
      'Self-ballasted modular installations for IT parks, malls, and airports',
      'Interactive product demo tables, touch kiosks, and retail displays',
      'Multi-city roadshow structures engineered for fast overnight setup',
      'Custom fabrications compliant with strict Grade-A venue guidelines',
    ],
  },
  {
    id: 'interiors',
    number: '04',
    navAnchor: 'interiors',
    title: 'Interior Designing',
    subtitle: 'Turnkey corporate offices, industrial experience centres, and commercial spaces in Pune & beyond.',
    categoryFilter: 'Interior',
    requirementOption: 'Corporate & Commercial Interior Design',
    image: MEDIA_ASSETS.interiorCorporateHq,
    imageAlt: 'Turnkey modern corporate office interior with fluted wood panels and glass conference room',
    bullets: [
      'Complete space planning, 3D interior visualization, and material boards',
      'Executive headquarters, client experience centres, and R&D offices',
      'Turnkey civil, MEP, acoustic glazing, custom millwork, and lighting',
      'Fixed-milestone scheduling with transparent BOQ cost control',
    ],
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: '01',
    title: 'Site Visit & Brief',
    duration: 'Day 1–2',
    description:
      'We study your floor plan, hall traffic flow, product dimensions, and lead-generation goals before sketching a single line.',
  },
  {
    step: '02',
    title: '3D Design',
    duration: '48–72 Hours',
    description:
      'You receive photorealistic 3D renders, material finishes, lighting layouts, and an itemized BOQ for fast internal approval.',
  },
  {
    step: '03',
    title: 'Fabrication',
    duration: 'In-House Workshop',
    description:
      'Our Pune carpentry, metalwork, paint, and print teams pre-build and dry-fit critical sections to eliminate on-site surprises.',
  },
  {
    step: '04',
    title: 'Installation',
    duration: 'Pre-Show Handover',
    description:
      'Dedicated site supervisors manage venue permissions, electricals, graphics, and deep cleaning—handing over hours ahead of opening.',
  },
  {
    step: '05',
    title: 'Dismantling',
    duration: 'Post-Show Wrap',
    description:
      'Clean, damage-free dismantling, safe packaging of client exhibits, and optional warehouse storage for your next exhibition.',
  },
];

export const WHY_PROSPECT: WhyProspectItem[] = [
  {
    id: 'creative',
    title: 'Creative Designs',
    description:
      'Architectural silhouettes and brand-first lighting that stand out cleanly across crowded exhibition halls.',
    icon: 'compass',
  },
  {
    id: 'quality',
    title: 'Quality Work',
    description:
      'Seamless laminate joints, crisp backlit print color calibration, and exhibition-grade structural finishes.',
    icon: 'shield',
  },
  {
    id: 'communication',
    title: 'Clear Communication',
    description:
      'One senior project manager sends daily workshop photo updates and transparent milestone checklists.',
    icon: 'message',
  },
  {
    id: 'needs',
    title: 'Understands Your Needs',
    description:
      'Deep experience in manufacturing, pharma, electronics, textile, and die & mould B2B buyer workflows.',
    icon: 'target',
  },
  {
    id: 'ontime',
    title: 'On-time Delivery',
    description:
      'Show-floor handover completed ahead of schedule so your sales team rehearses calmly before doors open.',
    icon: 'clock',
  },
  {
    id: 'budget',
    title: 'Budget Friendly',
    description:
      'Direct in-house fabrication in Talegaon Dabhade keeps pricing honest with zero middleman markups.',
    icon: 'wallet',
  },
];

export const STATS: StatItem[] = [
  {
    value: 10,
    suffix: '+',
    label: 'Years in Spatial Design',
    detail: 'Serving B2B exhibitors from Pune since day one',
  },
  {
    value: 500,
    suffix: '+',
    label: 'Projects Delivered',
    detail: 'Exhibition stands, events, activations & interiors',
  },
  {
    value: 35,
    suffix: '+',
    label: 'Major Trade Venues',
    detail: 'BIEC, Pragati Maidan, BEC Mumbai, Messe & DWTC',
  },
  {
    value: 3,
    suffix: '',
    label: 'Global Markets',
    detail: 'Pan-India execution plus Germany & Dubai',
  },
];

export const CLIENTS: ClientLogoItem[] = [
  { name: 'Kalyani Tooling', sector: 'Die & Mould', accent: '#EA4C18', monogram: 'KT' },
  { name: 'PharmaVue Life', sector: 'Pharmaceuticals', accent: '#0D9488', monogram: 'PV' },
  { name: 'Quantum Drives', sector: 'Automation', accent: '#2563EB', monogram: 'QD' },
  { name: 'Deccan Precision', sector: 'CNC & Tooling', accent: '#D97706', monogram: 'DP' },
  { name: 'Sahyadri Looms', sector: 'Textile Machinery', accent: '#DC2626', monogram: 'SL' },
  { name: 'Verve Circuits', sector: 'Electronics', accent: '#4F46E5', monogram: 'VC' },
  { name: 'Indus Hydraulics', sector: 'Manufacturing', accent: '#0284C7', monogram: 'IH' },
  { name: 'BioMatrix Labs', sector: 'Pharma Tech', accent: '#059669', monogram: 'BM' },
  { name: 'Apex Polymers', sector: 'Plastics & Mould', accent: '#EA580C', monogram: 'AP' },
  { name: 'Taurus Mechatronics', sector: 'Robotics', accent: '#B91C1C', monogram: 'TM' },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote:
      'Prospect Designs handled our 96 sq.m island stand at IMTEX with remarkable engineering discipline. Our 900 kg die assemblies sat flush on reinforced plinths, and handover was complete 12 hours before show opening.',
    author: 'Rajesh Deshmukh',
    role: 'Head of Marketing',
    company: 'Kalyani Tooling Systems',
    industry: 'Die & Mould Manufacturing',
    outcome: '140+ export RFQs captured in 5 days',
  },
  {
    id: 't2',
    quote:
      'Coordinating an international pavilion in Dubai from Pune usually feels stressful. Their team managed 3D approvals, local regulatory checks, and glass acoustic rooms effortlessly—our booth felt calmer and sharper than every competitor in the hall.',
    author: 'Dr. Meenakshi Kulkarni',
    role: 'VP – Global Business Development',
    company: 'PharmaVue Life Sciences',
    industry: 'Pharmaceuticals',
    outcome: '38 international distributor meetings closed',
  },
  {
    id: 't3',
    quote:
      'From our Hannover Messe double-decker stand to our new Chakan corporate experience centre, Prospect understands how B2B engineering buyers evaluate trust through physical space. Zero hidden costs and rock-solid finishing.',
    author: 'Vikramaditya Joshi',
    role: 'Managing Director',
    company: 'Deccan Precision Drives',
    industry: 'Industrial Electronics & Drives',
    outcome: 'Delivered 6,800 sq.ft HQ turnkey in 75 days',
  },
  {
    id: 't4',
    quote:
      'For our 600-delegate annual dealer summit in Pune, the curved LED stage and lighting cues ran with broadcast precision. Our leadership could focus on partners while Prospect quietly ran the entire floor.',
    author: 'Ananya Patwardhan',
    role: 'Corporate Communications Lead',
    company: 'Sahyadri Industrial Group',
    industry: 'Textile & Heavy Manufacturing',
    outcome: '100% cue accuracy across 640 delegates',
  },
];

export const UPCOMING_EXHIBITIONS: UpcomingExhibition[] = [
  {
    id: 'imtex',
    name: 'IMTEX & Tooltech',
    dates: 'Jan 21 – 27, 2027',
    city: 'BIEC, Bengaluru',
    country: 'India',
    sector: 'Machine Tools & Die-Mould',
    slotsOpen: '4 Design Slots Open',
  },
  {
    id: 'cphi',
    name: 'CPHI & PMEC India',
    dates: 'Nov 24 – 26, 2026',
    city: 'India Expo Mart, NCR',
    country: 'India',
    sector: 'Pharmaceuticals & Machinery',
    slotsOpen: '3 Design Slots Open',
  },
  {
    id: 'hannover',
    name: 'Hannover Messe',
    dates: 'Apr 12 – 16, 2027',
    city: 'Hannover Exhibition Grounds',
    country: 'Germany',
    sector: 'Industrial Automation & Drives',
    slotsOpen: 'International Desk Open',
  },
  {
    id: 'arab-health',
    name: 'WHX / Arab Health',
    dates: 'Feb 08 – 11, 2027',
    city: 'Dubai World Trade Centre',
    country: 'Dubai, UAE',
    sector: 'Healthcare & Pharma',
    slotsOpen: 'International Desk Open',
  },
];

export const FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'How early should we book our exhibition stall design and fabrication?',
    answer:
      'For domestic shows in Pune, Mumbai, Bengaluru, or Delhi NCR, we recommend briefing us 4–6 weeks before the show date. For international stands in Germany or Dubai, 8–10 weeks allows smooth organizer approvals, structural certifications, and cost-efficient logistics.',
  },
  {
    id: 'faq-2',
    question: 'Do you charge for the initial 3D exhibition stand concept?',
    answer:
      'No. Once you share your stall dimensions, open sides, and brand guidelines, we provide an initial 3D architectural design proposal and transparent cost estimate at no obligation.',
  },
  {
    id: 'faq-3',
    question: 'How do you manage international exhibitions in Germany and Dubai from Pune?',
    answer:
      'We handle complete 3D design, technical working drawings, graphic production, and organizer compliance from our Pune studio, while executing fabrication and on-site installation with our vetted partner workshops and travelling project supervisors in Germany and Dubai.',
  },
  {
    id: 'faq-4',
    question: 'Can heavy industrial machines or die-and-mould assemblies be displayed safely?',
    answer:
      'Yes. Manufacturing, die & mould, electronics, and textile machinery are our core specialties. We engineer reinforced MS/timber plinths, floor load distribution plates, concealed three-phase power routing, and dedicated lifting clearances.',
  },
  {
    id: 'faq-5',
    question: 'Do you build reusable modular exhibition stands for multiple shows per year?',
    answer:
      'Yes. If you exhibit at 3 or more shows annually, we can design a hybrid custom-modular system with interchangeable fabric graphics and store your structure at our Talegaon Dabhade facility to cut repeat-show costs by up to 40%.',
  },
  {
    id: 'faq-6',
    question: 'What is included in a turnkey exhibition stall package?',
    answer:
      'Everything from 3D visualization, structural fabrication, raised flooring, branded graphics, LED/track lighting, AV screens, lounge furniture, on-site installation, show-days technical standby, and post-show dismantling.',
  },
];

export const REQUIREMENT_OPTIONS = [
  'Exhibition Stall Design & Fabrication',
  'International Pavilion (Germany / Dubai)',
  'Corporate Event & Stage Setup',
  'Spaces & Brand Activation',
  'Corporate & Commercial Interior Design',
] as const;
