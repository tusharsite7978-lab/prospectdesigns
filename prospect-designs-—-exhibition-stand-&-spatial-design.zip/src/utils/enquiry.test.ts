import test from 'node:test';
import assert from 'node:assert/strict';
import { PROJECTS } from '../data/content';
import {
  buildWhatsAppUrl,
  filterProjects,
  getAdjacentProjects,
  getCategoryCounts,
  validateEnquiry,
} from './enquiry';

test('filterProjects returns all projects for "All" and filters accurately by category', () => {
  const all = filterProjects(PROJECTS, 'All');
  assert.equal(all.length, PROJECTS.length);

  const exhibitions = filterProjects(PROJECTS, 'Exhibition');
  assert.ok(exhibitions.length >= 3);
  assert.ok(exhibitions.every((p) => p.category === 'Exhibition'));

  const events = filterProjects(PROJECTS, 'Event');
  assert.equal(events.length, 1);
  assert.equal(events[0].category, 'Event');

  const interiors = filterProjects(PROJECTS, 'Interior');
  assert.equal(interiors.length, 1);
  assert.equal(interiors[0].category, 'Interior');

  const activations = filterProjects(PROJECTS, 'Activation');
  assert.equal(activations.length, 1);
  assert.equal(activations[0].category, 'Activation');
});

test('getCategoryCounts totals match project inventory', () => {
  const counts = getCategoryCounts(PROJECTS);
  assert.equal(counts.All, PROJECTS.length);
  assert.equal(
    counts.Exhibition + counts.Event + counts.Interior + counts.Activation,
    PROJECTS.length
  );
});

test('getAdjacentProjects wraps cleanly at start and end of list', () => {
  const first = getAdjacentProjects(PROJECTS, PROJECTS[0].slug);
  assert.equal(first.prev?.slug, PROJECTS[PROJECTS.length - 1].slug);
  assert.equal(first.next?.slug, PROJECTS[1].slug);

  const missing = getAdjacentProjects(PROJECTS, 'non-existent-slug');
  assert.equal(missing.prev, null);
  assert.equal(missing.next, null);
});

test('validateEnquiry rejects empty or malformed fields and passes complete B2B briefs', () => {
  const emptyResult = validateEnquiry({
    name: '',
    phone: '123',
    company: '',
    requirement: '',
    message: 'hi',
  });
  assert.equal(emptyResult.isValid, false);
  assert.ok(emptyResult.errors.name);
  assert.ok(emptyResult.errors.phone);
  assert.ok(emptyResult.errors.company);
  assert.ok(emptyResult.errors.requirement);
  assert.ok(emptyResult.errors.message);

  const validResult = validateEnquiry({
    name: 'Aarav Kulkarni',
    phone: '+91 98220 11223',
    company: 'Precision Moulds Pvt Ltd',
    requirement: 'Exhibition Stall Design & Fabrication',
    message: 'Need a 54 sq.m 3-side open stand for IMTEX Bengaluru.',
  });
  assert.equal(validResult.isValid, true);
  assert.deepEqual(validResult.errors, {});
});

test('buildWhatsAppUrl targets Prospect Designs number with encoded enquiry payload', () => {
  const url = buildWhatsAppUrl({
    name: 'Priya Shah',
    phone: '9823012345',
    company: 'Nova Pharma',
    requirement: 'International Pavilion (Germany / Dubai)',
    message: '36 sq.m booth at Arab Health Dubai.',
  });
  assert.ok(url.startsWith('https://wa.me/919325993399?text='));
  const decoded = decodeURIComponent(url.split('text=')[1]);
  assert.match(decoded, /Priya Shah/);
  assert.match(decoded, /Nova Pharma/);
  assert.match(decoded, /Arab Health Dubai/);
});
