import type { ProjectCaseStudy, ProjectCategory } from '../data/content';

export interface EnquiryFormData {
  name: string;
  phone: string;
  company: string;
  requirement: string;
  message: string;
}

export interface EnquiryValidationErrors {
  name?: string;
  phone?: string;
  company?: string;
  requirement?: string;
  message?: string;
}

export interface EnquiryValidationResult {
  isValid: boolean;
  errors: EnquiryValidationErrors;
}

/**
 * Pure filter helper for Selected Work portfolio grid.
 */
export function filterProjects(
  projects: readonly ProjectCaseStudy[],
  category: ProjectCategory
): ProjectCaseStudy[] {
  if (category === 'All') {
    return [...projects];
  }
  return projects.filter((project) => project.category === category);
}

/**
 * Counts projects per category for accessible filter metadata.
 */
export function getCategoryCounts(
  projects: readonly ProjectCaseStudy[]
): Record<ProjectCategory, number> {
  const counts: Record<ProjectCategory, number> = {
    All: projects.length,
    Exhibition: 0,
    Event: 0,
    Interior: 0,
    Activation: 0,
  };

  for (const project of projects) {
    counts[project.category] += 1;
  }

  return counts;
}

/**
 * Returns cyclic previous and next case studies for seamless portfolio navigation.
 */
export function getAdjacentProjects(
  projects: readonly ProjectCaseStudy[],
  currentSlug: string
): { prev: ProjectCaseStudy | null; next: ProjectCaseStudy | null } {
  if (projects.length <= 1) {
    return { prev: null, next: null };
  }
  const idx = projects.findIndex((p) => p.slug === currentSlug);
  if (idx === -1) {
    return { prev: null, next: null };
  }
  const prev = projects[(idx - 1 + projects.length) % projects.length];
  const next = projects[(idx + 1) % projects.length];
  return { prev, next };
}

/**
 * Validates B2B enquiry form fields strictly without bypassing empty/invalid inputs.
 */
export function validateEnquiry(form: EnquiryFormData): EnquiryValidationResult {
  const errors: EnquiryValidationErrors = {};

  const trimmedName = form.name.trim();
  if (trimmedName.length < 2) {
    errors.name = 'Please enter your full name (at least 2 characters).';
  }

  const digitsOnly = form.phone.replace(/[^\d]/g, '');
  if (digitsOnly.length < 10 || digitsOnly.length > 15) {
    errors.phone = 'Please enter a valid 10 to 15 digit phone or WhatsApp number.';
  }

  const trimmedCompany = form.company.trim();
  if (trimmedCompany.length < 2) {
    errors.company = 'Please enter your company or organisation name.';
  }

  if (!form.requirement.trim()) {
    errors.requirement = 'Please select your project requirement.';
  }

  const trimmedMessage = form.message.trim();
  if (trimmedMessage.length < 8) {
    errors.message = 'Please share a brief note (stall size, exhibition name, or dates).';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Constructs a pre-filled WhatsApp click-to-chat URL for Prospect Designs.
 */
export function buildWhatsAppUrl(
  form: EnquiryFormData,
  whatsappNumber = '919325993399'
): string {
  const lines = [
    'Hello Prospect Designs Team,',
    `Name: ${form.name.trim() || 'Not provided'}`,
    `Company: ${form.company.trim() || 'Not provided'}`,
    `Phone: ${form.phone.trim() || 'Not provided'}`,
    `Requirement: ${form.requirement.trim() || 'General Enquiry'}`,
    `Brief: ${form.message.trim() || 'Looking for a design consultation.'}`,
  ];
  const encodedText = encodeURIComponent(lines.join('\n'));
  return `https://wa.me/${whatsappNumber}?text=${encodedText}`;
}
