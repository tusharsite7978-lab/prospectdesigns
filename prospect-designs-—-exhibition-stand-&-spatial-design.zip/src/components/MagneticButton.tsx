import { useRef, type MouseEvent, type ReactNode } from 'react';

interface MagneticButtonProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  href?: string;
  type?: 'button' | 'submit';
  ariaLabel?: string;
  strength?: number;
}

/**
 * Subtle compositor-only magnetic pull micro-interaction (transform: translate3d).
 * Automatically inert on coarse-pointer (mobile) devices and prefers-reduced-motion.
 */
export function MagneticButton({
  children,
  className = '',
  onClick,
  href,
  type = 'button',
  ariaLabel,
  strength = 0.22,
}: MagneticButtonProps) {
  const elRef = useRef<HTMLElement | null>(null);

  const handleMouseMove = (e: MouseEvent<HTMLElement>) => {
    const node = elRef.current;
    if (!node) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce), (pointer: coarse)').matches) {
      return;
    }
    const rect = node.getBoundingClientRect();
    const relX = (e.clientX - rect.left - rect.width / 2) * strength;
    const relY = (e.clientY - rect.top - rect.height / 2) * strength;
    node.style.transform = `translate3d(${relX.toFixed(1)}px, ${relY.toFixed(1)}px, 0)`;
  };

  const handleMouseLeave = () => {
    const node = elRef.current;
    if (!node) return;
    node.style.transform = 'translate3d(0, 0, 0)';
  };

  const sharedClasses = `inline-flex items-center justify-center whitespace-nowrap shrink-0 transition-transform duration-200 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18] ${className}`;

  if (href) {
    return (
      <a
        ref={(n) => {
          elRef.current = n;
        }}
        href={href}
        onClick={onClick}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        aria-label={ariaLabel}
        className={sharedClasses}
      >
        {children}
      </a>
    );
  }

  return (
    <button
      ref={(n) => {
        elRef.current = n;
      }}
      type={type}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      aria-label={ariaLabel}
      className={sharedClasses}
    >
      {children}
    </button>
  );
}
