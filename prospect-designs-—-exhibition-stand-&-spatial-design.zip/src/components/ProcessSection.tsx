import { PROCESS_STEPS, UI_COPY, type LanguageCode } from '../data/content';
import { Reveal } from './Reveal';

interface ProcessSectionProps {
  language: LanguageCode;
}

const STEP_DELAYS: Array<'' | 'delay-75' | 'delay-100' | 'delay-150' | 'delay-200'> = [
  '',
  'delay-75',
  'delay-100',
  'delay-150',
  'delay-200',
];

export function ProcessSection({ language }: ProcessSectionProps) {
  const copy = UI_COPY[language].sections;

  return (
    <section
      id="process"
      aria-labelledby="process-heading"
      className="py-20 sm:py-24 lg:py-28 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-14 lg:mb-16">
          <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
            {copy.processEyebrow}
          </p>
          <h2
            id="process-heading"
            className="text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold tracking-tight text-[#0E0E0E] leading-[1.12]"
          >
            {copy.processTitle}
          </h2>
        </div>

        {/* Horizontal 5-Step Architectural Timeline */}
        <div className="relative">
          {/* Desktop horizontal connector hairline */}
          <div
            aria-hidden="true"
            className="hidden lg:block absolute top-6 left-6 right-6 h-px bg-neutral-200"
          />

          <ol className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-5">
            {PROCESS_STEPS.map((item, idx) => (
              <Reveal key={item.step} delayClass={STEP_DELAYS[idx]}>
                <li className="relative flex flex-col h-full">
                  <div className="flex items-center gap-3 mb-5">
                    <span className="relative z-10 inline-flex items-center justify-center h-12 w-12 rounded-xl bg-[#0E0E0E] text-white text-sm font-semibold tabular-nums shrink-0">
                      {item.step}
                    </span>
                    <span className="text-xs font-medium text-neutral-500">
                      {item.duration}
                    </span>
                  </div>

                  <div className="flex-1 rounded-2xl bg-[#FAFAFA] border border-neutral-200/80 p-5">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0E0E0E] mb-2">
                      {item.title}
                    </h3>
                    <p className="text-sm text-neutral-600 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
