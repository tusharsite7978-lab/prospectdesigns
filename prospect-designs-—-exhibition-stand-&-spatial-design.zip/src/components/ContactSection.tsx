import { useEffect, useState, type FormEvent } from 'react';
import {
  CheckCircle2,
  ExternalLink,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Send,
} from 'lucide-react';
import {
  CONTACT_INFO,
  REQUIREMENT_OPTIONS,
  UI_COPY,
  type LanguageCode,
} from '../data/content';
import {
  buildWhatsAppUrl,
  validateEnquiry,
  type EnquiryFormData,
  type EnquiryValidationErrors,
} from '../utils/enquiry';

interface ContactSectionProps {
  language: LanguageCode;
  prefilledRequirement?: string;
  prefilledMessage?: string;
}

export function ContactSection({
  language,
  prefilledRequirement,
  prefilledMessage,
}: ContactSectionProps) {
  const copy = UI_COPY[language].sections;

  const [form, setForm] = useState<EnquiryFormData>({
    name: '',
    phone: '',
    company: '',
    requirement: prefilledRequirement || REQUIREMENT_OPTIONS[0],
    message: prefilledMessage || '',
  });
  const [errors, setErrors] = useState<EnquiryValidationErrors>({});
  const [submittedRecord, setSubmittedRecord] = useState<{
    referenceId: string;
    data: EnquiryFormData;
    whatsAppHref: string;
  } | null>(null);

  // Update form whenever user clicks "Know More", "Book Stall Design", or "Request Similar Stand"
  useEffect(() => {
    if (prefilledRequirement || prefilledMessage) {
      setSubmittedRecord(null);
      setErrors({});
      setForm((prev) => ({
        ...prev,
        requirement: prefilledRequirement || prev.requirement,
        message: prefilledMessage || prev.message,
      }));
    }
  }, [prefilledRequirement, prefilledMessage]);

  const handleFieldChange = (field: keyof EnquiryFormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validation = validateEnquiry(form);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    const referenceId = `PD-${Date.now().toString().slice(-6)}`;
    const whatsAppHref = buildWhatsAppUrl(form, CONTACT_INFO.whatsappNumber);
    setErrors({});
    setSubmittedRecord({
      referenceId,
      data: { ...form },
      whatsAppHref,
    });
  };

  const handleReset = () => {
    setSubmittedRecord(null);
    setForm({
      name: '',
      phone: '',
      company: '',
      requirement: REQUIREMENT_OPTIONS[0],
      message: '',
    });
    setErrors({});
  };

  const liveWhatsAppUrl = buildWhatsAppUrl(form, CONTACT_INFO.whatsappNumber);

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="py-20 sm:py-24 lg:py-28 bg-[#FAFAFA] border-t border-neutral-200/70"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12 lg:mb-14">
          <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
            {copy.contactEyebrow}
          </p>
          <h2
            id="contact-heading"
            className="text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold tracking-tight text-[#0E0E0E] leading-[1.12] mb-4"
          >
            {copy.contactTitle}
          </h2>
          <p className="text-base text-neutral-600 leading-relaxed">
            Tell us your upcoming trade show, stall size, or interior brief. Our Pune design team
            responds within 4 business hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Left 7 Columns: Short Enquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-neutral-200/80 p-6 sm:p-8 lg:p-10">
            {submittedRecord ? (
              <div
                role="status"
                aria-live="polite"
                className="h-full flex flex-col justify-between py-2"
              >
                <div>
                  <div className="h-12 w-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-5">
                    <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="text-xs font-semibold text-emerald-700 tabular-nums mb-2">
                    Enquiry Received · Ref {submittedRecord.referenceId}
                  </p>
                  <h3 className="text-2xl font-semibold text-[#0E0E0E] mb-3">
                    Thank you, {submittedRecord.data.name}.
                  </h3>
                  <p className="text-sm sm:text-base text-neutral-600 leading-relaxed mb-6">
                    Your brief for{' '}
                    <span className="font-semibold text-[#0E0E0E]">
                      {submittedRecord.data.company}
                    </span>{' '}
                    ({submittedRecord.data.requirement}) has been logged. Our design lead will
                    reach out on{' '}
                    <span className="font-semibold text-[#0E0E0E] tabular-nums">
                      {submittedRecord.data.phone}
                    </span>
                    .
                  </p>

                  <div className="rounded-xl bg-[#FAFAFA] border border-neutral-200 p-4 mb-8 text-sm text-neutral-700">
                    <p className="text-xs font-semibold text-neutral-500 mb-1">Your Brief</p>
                    <p>{submittedRecord.data.message}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <a
                    href={submittedRecord.whatsAppHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 min-h-[48px] px-5 py-3 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white text-sm font-semibold transition-colors"
                  >
                    <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>Also Send Brief on WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="inline-flex items-center justify-center min-h-[48px] px-5 py-3 rounded-xl border border-neutral-300 hover:border-[#0E0E0E] text-sm font-semibold text-[#0E0E0E] transition-colors cursor-pointer"
                  >
                    Submit Another Enquiry
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="enquiry-name"
                      className="block text-xs font-semibold text-neutral-700 mb-1.5"
                    >
                      Your Name <span className="text-[#EA4C18]">*</span>
                    </label>
                    <input
                      id="enquiry-name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      value={form.name}
                      onChange={(e) => handleFieldChange('name', e.target.value)}
                      placeholder="e.g. Rajesh Deshmukh"
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? 'error-name' : undefined}
                      className={`w-full min-h-[46px] px-4 rounded-xl border bg-white text-sm text-[#0E0E0E] placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#EA4C18]/25 focus:border-[#EA4C18] ${
                        errors.name ? 'border-red-500' : 'border-neutral-300'
                      }`}
                    />
                    {errors.name && (
                      <p id="error-name" role="alert" className="mt-1.5 text-xs text-red-600">
                        {errors.name}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="enquiry-phone"
                      className="block text-xs font-semibold text-neutral-700 mb-1.5"
                    >
                      Phone / WhatsApp <span className="text-[#EA4C18]">*</span>
                    </label>
                    <input
                      id="enquiry-phone"
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      value={form.phone}
                      onChange={(e) => handleFieldChange('phone', e.target.value)}
                      placeholder="+91 98220 00000"
                      aria-invalid={Boolean(errors.phone)}
                      aria-describedby={errors.phone ? 'error-phone' : undefined}
                      className={`w-full min-h-[46px] px-4 rounded-xl border bg-white text-sm text-[#0E0E0E] placeholder:text-neutral-400 tabular-nums focus:outline-none focus:ring-2 focus:ring-[#EA4C18]/25 focus:border-[#EA4C18] ${
                        errors.phone ? 'border-red-500' : 'border-neutral-300'
                      }`}
                    />
                    {errors.phone && (
                      <p id="error-phone" role="alert" className="mt-1.5 text-xs text-red-600">
                        {errors.phone}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="enquiry-company"
                      className="block text-xs font-semibold text-neutral-700 mb-1.5"
                    >
                      Company Name <span className="text-[#EA4C18]">*</span>
                    </label>
                    <input
                      id="enquiry-company"
                      name="company"
                      type="text"
                      autoComplete="organization"
                      value={form.company}
                      onChange={(e) => handleFieldChange('company', e.target.value)}
                      placeholder="e.g. Kalyani Precision Pvt Ltd"
                      aria-invalid={Boolean(errors.company)}
                      aria-describedby={errors.company ? 'error-company' : undefined}
                      className={`w-full min-h-[46px] px-4 rounded-xl border bg-white text-sm text-[#0E0E0E] placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#EA4C18]/25 focus:border-[#EA4C18] ${
                        errors.company ? 'border-red-500' : 'border-neutral-300'
                      }`}
                    />
                    {errors.company && (
                      <p id="error-company" role="alert" className="mt-1.5 text-xs text-red-600">
                        {errors.company}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="enquiry-requirement"
                      className="block text-xs font-semibold text-neutral-700 mb-1.5"
                    >
                      Requirement <span className="text-[#EA4C18]">*</span>
                    </label>
                    <select
                      id="enquiry-requirement"
                      name="requirement"
                      value={form.requirement}
                      onChange={(e) => handleFieldChange('requirement', e.target.value)}
                      aria-invalid={Boolean(errors.requirement)}
                      className="w-full min-h-[46px] px-4 rounded-xl border border-neutral-300 bg-white text-sm text-[#0E0E0E] focus:outline-none focus:ring-2 focus:ring-[#EA4C18]/25 focus:border-[#EA4C18] cursor-pointer"
                    >
                      {REQUIREMENT_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="enquiry-message"
                    className="block text-xs font-semibold text-neutral-700 mb-1.5"
                  >
                    Project Brief (Exhibition Name, Size, Dates) <span className="text-[#EA4C18]">*</span>
                  </label>
                  <textarea
                    id="enquiry-message"
                    name="message"
                    rows={4}
                    value={form.message}
                    onChange={(e) => handleFieldChange('message', e.target.value)}
                    placeholder="e.g. 54 sq.m 3-side open exhibition stall at IMTEX Bengaluru, need 3D concept and turnkey build."
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'error-message' : undefined}
                    className={`w-full px-4 py-3 rounded-xl border bg-white text-sm text-[#0E0E0E] placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#EA4C18]/25 focus:border-[#EA4C18] resize-y ${
                      errors.message ? 'border-red-500' : 'border-neutral-300'
                    }`}
                  />
                  {errors.message && (
                    <p id="error-message" role="alert" className="mt-1.5 text-xs text-red-600">
                      {errors.message}
                    </p>
                  )}
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    type="submit"
                    className="min-h-[48px] px-6 py-3 rounded-xl bg-[#EA4C18] hover:bg-[#D23E0E] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Send className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>Request Free 3D Proposal</span>
                  </button>

                  <a
                    href={liveWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="whatsapp-submit-link"
                    className="min-h-[48px] px-5 py-3 rounded-xl border border-neutral-300 hover:border-[#16A34A] hover:text-[#15803D] text-neutral-800 text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors"
                  >
                    <MessageCircle className="h-4 w-4 text-[#16A34A] shrink-0" aria-hidden="true" />
                    <span>Send via WhatsApp</span>
                  </a>
                </div>
              </form>
            )}
          </div>

          {/* Right 5 Columns: Direct Studio Details + Map */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="rounded-2xl bg-white border border-neutral-200/80 p-6 sm:p-7 space-y-5">
              <div>
                <p className="text-xs font-semibold text-[#EA4C18] mb-1">
                  Pune Studio &amp; Fabrication Hub
                </p>
                <h3 className="text-lg font-semibold text-[#0E0E0E]">
                  {CONTACT_INFO.companyLegal}
                </h3>
              </div>

              <div className="space-y-4 text-sm text-neutral-700">
                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 text-[#EA4C18] shrink-0 mt-1" aria-hidden="true" />
                  <p className="leading-relaxed">{CONTACT_INFO.address}</p>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="h-4 w-4 text-[#EA4C18] shrink-0 mt-1" aria-hidden="true" />
                  <div className="flex flex-col gap-1 tabular-nums">
                    {CONTACT_INFO.phones.map((phone) => (
                      <a
                        key={phone.href}
                        href={phone.href}
                        className="font-medium hover:text-[#EA4C18] transition-colors"
                      >
                        {phone.display}
                      </a>
                    ))}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="h-4 w-4 text-[#EA4C18] shrink-0 mt-1" aria-hidden="true" />
                  <div className="flex flex-col gap-1">
                    {CONTACT_INFO.emails.map((email) => (
                      <a
                        key={email.href}
                        href={email.href}
                        className="font-medium hover:text-[#EA4C18] transition-colors break-all"
                      >
                        {email.display}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Clean Architectural Map Card */}
            <div className="flex-1 min-h-[240px] rounded-2xl overflow-hidden border border-neutral-200/80 bg-white flex flex-col">
              <div className="relative flex-1 min-h-[200px] bg-neutral-100">
                <iframe
                  title="Prospect Designs Studio Location — Talegaon Dabhade, Pune"
                  src={CONTACT_INFO.mapEmbedUrl}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="h-full w-full min-h-[200px] border-0 grayscale-[20%]"
                />
              </div>
              <div className="px-5 py-3.5 bg-white border-t border-neutral-200/70 flex items-center justify-between gap-3">
                <span className="text-xs text-neutral-600 truncate">
                  Talegaon Dabhade · Pune 410506
                </span>
                <a
                  href={CONTACT_INFO.mapDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#EA4C18] hover:text-[#D23E0E] whitespace-nowrap shrink-0"
                >
                  <span>Directions</span>
                  <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
