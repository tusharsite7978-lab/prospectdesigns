import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PROJECTS, type ProjectCaseStudy } from '../data/content';
import { getAdjacentProjects } from '../utils/enquiry';
import { ResilientImage } from './ResilientImage';
import { MagneticButton } from './MagneticButton';

interface CaseStudyViewProps {
  project: ProjectCaseStudy;
  onBack: () => void;
  onSelectProject: (project: ProjectCaseStudy) => void;
  onEnquireSimilar: (project: ProjectCaseStudy) => void;
}

export function CaseStudyView({
  project,
  onBack,
  onSelectProject,
  onEnquireSimilar,
}: CaseStudyViewProps) {
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  // Reset active gallery index & scroll to top when switching case studies
  useEffect(() => {
    setActiveImageIdx(0);
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [project.slug]);

  const activeGalleryItem = project.gallery[activeImageIdx] ?? project.gallery[0];
  const { prev, next } = getAdjacentProjects(PROJECTS, project.slug);

  return (
    <article
      aria-labelledby="case-study-title"
      className="bg-white min-h-screen pt-8 pb-24 sm:pt-12 sm:pb-28"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Breadcrumb */}
        <div className="mb-8 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 min-h-[44px] px-3 -ml-3 rounded-lg text-sm font-semibold text-neutral-700 hover:text-[#EA4C18] transition-colors cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Back to Selected Work</span>
          </button>

          <div className="text-xs sm:text-sm text-neutral-500 flex items-center gap-2">
            <span className="font-semibold text-[#EA4C18]">{project.category}</span>
            <span aria-hidden="true">/</span>
            <span className="tabular-nums">{project.year}</span>
          </div>
        </div>

        {/* Case Study Header */}
        <header className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end mb-10">
          <div className="lg:col-span-8">
            <p className="text-sm font-medium text-neutral-500 mb-3">
              {project.client} · {project.industry}
            </p>
            <h1
              id="case-study-title"
              className="text-3xl sm:text-5xl font-semibold tracking-tight text-[#0E0E0E] leading-[1.1] mb-4"
            >
              {project.title}
            </h1>
            <p className="text-base sm:text-lg text-neutral-600 leading-relaxed max-w-2xl">
              {project.summary}
            </p>
          </div>

          <div className="lg:col-span-4 flex lg:justify-end">
            <MagneticButton
              onClick={() => onEnquireSimilar(project)}
              className="min-h-[48px] px-6 py-3.5 rounded-xl bg-[#EA4C18] hover:bg-[#D23E0E] text-white text-sm font-semibold gap-2 cursor-pointer"
            >
              <span>Request a Similar Design</span>
              <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
            </MagneticButton>
          </div>
        </header>

        {/* Project Specifications Row */}
        <dl className="grid grid-cols-2 sm:grid-cols-4 gap-6 py-6 border-y border-neutral-200 mb-10">
          <div>
            <dt className="text-xs text-neutral-500 mb-1">Client</dt>
            <dd className="text-sm font-semibold text-[#0E0E0E]">{project.client}</dd>
          </div>
          <div>
            <dt className="text-xs text-neutral-500 mb-1">Industry</dt>
            <dd className="text-sm font-semibold text-[#0E0E0E]">{project.industry}</dd>
          </div>
          <div>
            <dt className="text-xs text-neutral-500 mb-1">Footprint / Scale</dt>
            <dd className="text-sm font-semibold text-[#0E0E0E] tabular-nums">
              {project.area}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-neutral-500 mb-1">Location</dt>
            <dd className="text-sm font-semibold text-[#0E0E0E]">{project.location}</dd>
          </div>
        </dl>

        {/* Interactive High-Res Image Gallery */}
        <section aria-label="Project gallery" className="mb-16">
          <div className="overflow-hidden rounded-2xl bg-neutral-100 border border-neutral-200/80 aspect-[16/9]">
            <ResilientImage
              src={activeGalleryItem.src}
              alt={activeGalleryItem.alt}
              width={activeGalleryItem.width}
              height={activeGalleryItem.height}
              priority
              fallbackLabel={project.title}
              className="h-full w-full object-cover"
            />
          </div>
          <p className="mt-3 text-xs sm:text-sm text-neutral-500">
            {activeGalleryItem.caption}
          </p>

          <div
            role="tablist"
            aria-label="Gallery views"
            className="mt-5 grid grid-cols-3 gap-3 sm:gap-4 max-w-2xl"
          >
            {project.gallery.map((item, idx) => {
              const isSelected = idx === activeImageIdx;
              return (
                <button
                  key={`${project.slug}-img-${idx}`}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  aria-label={`Show gallery photo ${idx + 1}: ${item.caption}`}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`relative overflow-hidden rounded-xl aspect-[16/10] border-2 transition-[transform,opacity,border-color] duration-200 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18] ${
                    isSelected
                      ? 'border-[#EA4C18] opacity-100'
                      : 'border-transparent opacity-65 hover:opacity-100'
                  }`}
                >
                  <ResilientImage
                    src={item.src}
                    alt={item.alt}
                    width={item.width}
                    height={item.height}
                    className="h-full w-full object-cover"
                  />
                </button>
              );
            })}
          </div>
        </section>

        {/* Narrative: Brief / Challenge / Solution + Quantified Results */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 mb-20">
          <div className="lg:col-span-7 space-y-10">
            <section>
              <h2 className="text-xl font-semibold text-[#0E0E0E] mb-3">01. The Brief</h2>
              <p className="text-base text-neutral-600 leading-relaxed">{project.brief}</p>
            </section>

            <section className="pt-8 border-t border-neutral-200">
              <h2 className="text-xl font-semibold text-[#0E0E0E] mb-3">02. The Challenge</h2>
              <p className="text-base text-neutral-600 leading-relaxed">
                {project.challenge}
              </p>
            </section>

            <section className="pt-8 border-t border-neutral-200">
              <h2 className="text-xl font-semibold text-[#0E0E0E] mb-3">03. Our Solution</h2>
              <p className="text-base text-neutral-600 leading-relaxed">
                {project.solution}
              </p>
            </section>
          </div>

          <aside className="lg:col-span-5">
            <div className="rounded-2xl bg-[#0E0E0E] text-white p-7 sm:p-8">
              <p className="text-xs font-semibold text-[#EA4C18] mb-2">Measurable Result</p>
              <h2 className="text-2xl font-semibold tracking-tight mb-6">
                Impact on the show floor
              </h2>

              <dl className="space-y-6 mb-8">
                {project.results.map((metric) => (
                  <div
                    key={metric.label}
                    className="flex items-baseline justify-between gap-4 pb-4 border-b border-white/10 last:border-b-0 last:pb-0"
                  >
                    <dt className="text-sm text-white/75 flex items-center gap-2">
                      <CheckCircle2
                        className="h-4 w-4 text-[#EA4C18] shrink-0"
                        aria-hidden="true"
                      />
                      <span>{metric.label}</span>
                    </dt>
                    <dd className="text-2xl sm:text-3xl font-semibold text-white tabular-nums shrink-0">
                      {metric.value}
                    </dd>
                  </div>
                ))}
              </dl>

              <button
                type="button"
                onClick={() => onEnquireSimilar(project)}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#EA4C18] hover:bg-[#D23E0E] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>Get a 3D Concept Like This</span>
                <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </button>
            </div>
          </aside>
        </div>

        {/* Next / Previous Case Study Switcher */}
        {(prev || next) && (
          <nav
            aria-label="Adjacent case studies"
            className="pt-10 border-t border-neutral-200 grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            {prev && (
              <button
                type="button"
                onClick={() => onSelectProject(prev)}
                className="group text-left p-5 rounded-2xl border border-neutral-200 hover:border-[#EA4C18]/50 transition-colors cursor-pointer"
              >
                <span className="inline-flex items-center gap-1.5 text-xs text-neutral-500 mb-2">
                  <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Previous Project</span>
                </span>
                <p className="text-base sm:text-lg font-semibold text-[#0E0E0E] group-hover:text-[#EA4C18] transition-colors">
                  {prev.title}
                </p>
                <p className="text-xs text-neutral-500 mt-1">
                  {prev.client} · {prev.category}
                </p>
              </button>
            )}
            {next && (
              <button
                type="button"
                onClick={() => onSelectProject(next)}
                className="group text-left sm:text-right p-5 rounded-2xl border border-neutral-200 hover:border-[#EA4C18]/50 transition-colors cursor-pointer"
              >
                <span className="inline-flex items-center sm:justify-end gap-1.5 text-xs text-neutral-500 mb-2">
                  <span>Next Project</span>
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                <p className="text-base sm:text-lg font-semibold text-[#0E0E0E] group-hover:text-[#EA4C18] transition-colors">
                  {next.title}
                </p>
                <p className="text-xs text-neutral-500 mt-1">
                  {next.client} · {next.category}
                </p>
              </button>
            )}
          </nav>
        )}
      </div>
    </article>
  );
}
