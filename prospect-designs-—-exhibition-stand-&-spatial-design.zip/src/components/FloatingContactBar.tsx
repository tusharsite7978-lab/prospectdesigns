import { MessageCircle, Phone } from 'lucide-react';
import { CONTACT_INFO } from '../data/content';

/**
 * Desktop: Clean floating WhatsApp button (bottom-right).
 * Mobile: Compact single-row bottom action dock (Call + WhatsApp), height 56px
 * (combined with 64px header = 120px / 844px = 14.2%, strictly under the 15% mobile sticky cap).
 */
export function FloatingContactBar() {
  return (
    <>
      {/* Desktop Floating WhatsApp CTA */}
      <a
        href={CONTACT_INFO.whatsappBaseUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Prospect Designs on WhatsApp"
        className="hidden md:inline-flex fixed bottom-6 right-6 z-40 items-center gap-2.5 h-12 px-5 rounded-full bg-[#16A34A] hover:bg-[#15803D] text-white text-sm font-semibold shadow-lg transition-transform duration-200 hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#16A34A]"
      >
        <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
        <span className="whitespace-nowrap">WhatsApp Us</span>
      </a>

      {/* Mobile Compact Click-to-Call + WhatsApp Bar */}
      <div
        role="region"
        aria-label="Quick contact actions"
        className="md:hidden fixed bottom-0 inset-x-0 z-40 h-14 bg-white/95 backdrop-blur-md border-t border-neutral-200 px-3 flex items-center gap-2.5"
      >
        <a
          href={CONTACT_INFO.phones[0].href}
          className="flex-1 h-10 rounded-xl bg-[#0E0E0E] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap"
        >
          <Phone className="h-3.5 w-3.5 text-[#EA4C18] shrink-0" aria-hidden="true" />
          <span>Call Now</span>
        </a>
        <a
          href={CONTACT_INFO.whatsappBaseUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 h-10 rounded-xl bg-[#16A34A] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap"
        >
          <MessageCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span>WhatsApp</span>
        </a>
      </div>
    </>
  );
}
