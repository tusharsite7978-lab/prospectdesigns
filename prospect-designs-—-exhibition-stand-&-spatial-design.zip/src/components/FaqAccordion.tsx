import { useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { FAQS, UI_COPY, type LanguageCode } from '../data/content';

interface FaqAccordionProps {
  language: LanguageCode;
}

export function FaqAccordion({ language }: FaqAccordionProps) {
  const [openId, setOpenId] = useState<string | null>(FAQS[0].id);
  const copy = UI_COPY[language].sections;

  const toggle = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="py-20 sm:py-24 lg:py-28 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          <div className="lg:col-span-4">
            <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
              {copy.faqEyebrow}
            </p>
            <h2
              id="faq-heading"
              className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#0E0E0E] leading-[1.14] mb-4"
            >
              {copy.faqTitle}
            </h2>
            <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
              Clear answers on lead times, 3D proposals, heavy machinery loads, and international
              builds in Germany &amp; Dubai.
            </p>
          </div>

          <div className="lg:col-span-8 divide-y divide-neutral-200 border-y border-neutral-200">
            {FAQS.map((faq) => {
              const isOpen = openId === faq.id;
              return (
                <div key={faq.id} className="py-1">
                  <h3>
                    <button
                      type="button"
                      onClick={() => toggle(faq.id)}
                      aria-expanded={isOpen}
                      aria-controls={`panel-${faq.id}`}
                      className="w-full min-h-[56px] py-4 flex items-center justify-between gap-4 text-left text-base sm:text-lg font-semibold text-[#0E0E0E] hover:text-[#EA4C18] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18]"
                    >
                      <span>{faq.question}</span>
                      <span
                        aria-hidden="true"
                        className="h-8 w-8 rounded-lg bg-[#FAFAFA] border border-neutral-200 flex items-center justify-center shrink-0 text-neutral-700"
                      >
                        {isOpen ? (
                          <Minus className="h-4 w-4 text-[#EA4C18]" />
                        ) : (
                          <Plus className="h-4 w-4" />
                        )}
                      </span>
                    </button>
                  </h3>
                  {isOpen && (
                    <div
                      id={`panel-${faq.id}`}
                      className="pb-5 pr-10 text-sm sm:text-base text-neutral-600 leading-relaxed"
                    >
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
