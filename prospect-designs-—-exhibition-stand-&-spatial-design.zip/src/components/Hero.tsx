import { useEffect, useRef } from 'react';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { MEDIA_ASSETS, UI_COPY, type LanguageCode } from '../data/content';
import { MagneticButton } from './MagneticButton';

interface HeroProps {
  language: LanguageCode;
  onViewWork: () => void;
  onConsultation: () => void;
}

export function Hero({ language, onViewWork, onConsultation }: HeroProps) {
  const sectionRef = useRef<HTMLElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const copy = UI_COPY[language].hero;

  const hasVideoSource = Boolean(MEDIA_ASSETS.heroVideoMp4 || MEDIA_ASSETS.heroVideoWebm);

  // Strict 60fps performance: pause hero video automatically when scrolled off-screen
  useEffect(() => {
    const video = videoRef.current;
    const section = sectionRef.current;
    if (!video || !section || !hasVideoSource) return;

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      video.pause();
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            void video.play().catch(() => {});
          } else {
            video.pause();
          }
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, [hasVideoSource]);

  return (
    <section
      id="top"
      ref={sectionRef}
      aria-label="Hero showcase"
      className="relative min-h-[calc(100svh-4rem)] lg:min-h-[calc(100svh-72px)] w-full overflow-hidden bg-[#0E0E0E] flex items-end"
    >
      {/* Full-bleed looping architectural backdrop (video-ready with crisp architectural poster fallback) */}
      <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
        {hasVideoSource ? (
          <video
            ref={videoRef}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            poster={MEDIA_ASSETS.heroPoster}
            className="h-full w-full object-cover object-center"
          >
            {MEDIA_ASSETS.heroVideoWebm && (
              <source src={MEDIA_ASSETS.heroVideoWebm} type="video/webm" />
            )}
            {MEDIA_ASSETS.heroVideoMp4 && (
              <source src={MEDIA_ASSETS.heroVideoMp4} type="video/mp4" />
            )}
          </video>
        ) : (
          <img
            src={MEDIA_ASSETS.heroPoster}
            alt=""
            width={1920}
            height={1080}
            loading="eager"
            decoding="sync"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover object-center animate-hero-drift"
          />
        )}

        {/* Measured architectural scrim for >= 4.5:1 text contrast across bright highlights */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0E0E0E]/92 via-[#0E0E0E]/55 to-[#0E0E0E]/35" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0E0E0E]/75 via-[#0E0E0E]/25 to-transparent" />
      </div>

      {/* Foreground Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 sm:pt-24 pb-24 md:pb-16 lg:pb-20">
        <div className="max-w-3xl">
          <p className="text-xs sm:text-sm font-medium tracking-wide text-white/80 mb-3 sm:mb-4">
            Prospect Designs · Talegaon Dabhade, Pune
          </p>

          <h1 className="text-[2.1rem] sm:text-5xl lg:text-[3.75rem] font-semibold text-white tracking-tight leading-[1.08] mb-4 sm:mb-5">
            {copy.headline}
          </h1>

          <p className="text-[15px] sm:text-lg text-white/85 leading-relaxed max-w-2xl mb-7 sm:mb-8">
            {copy.subtext}
          </p>

          {/* Primary & Secondary CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4 mb-8 sm:mb-10">
            <MagneticButton
              onClick={onViewWork}
              className="min-h-[48px] px-6 py-3.5 rounded-xl bg-[#EA4C18] hover:bg-[#D23E0E] text-white text-sm font-semibold gap-2 cursor-pointer"
            >
              <span>{copy.primaryCta}</span>
              <ArrowDownRight className="h-4 w-4 shrink-0" aria-hidden="true" />
            </MagneticButton>

            <MagneticButton
              onClick={onConsultation}
              className="min-h-[48px] px-6 py-3.5 rounded-xl bg-white/12 hover:bg-white/20 text-white border border-white/25 backdrop-blur-sm text-sm font-semibold gap-2 cursor-pointer"
            >
              <span>{copy.secondaryCta}</span>
              <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
            </MagneticButton>
          </div>

          {/* Clean unboxed Trust Row */}
          <div className="pt-5 sm:pt-6 border-t border-white/15 flex flex-wrap items-center gap-x-3 sm:gap-x-4 gap-y-2 text-xs sm:text-sm font-medium text-white/90 tabular-nums">
            {copy.trustRow.map((item, idx) => (
              <span key={item} className="inline-flex items-center gap-4">
                <span>{item}</span>
                {idx < copy.trustRow.length - 1 && (
                  <span aria-hidden="true" className="text-[#EA4C18]">
                    •
                  </span>
                )}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
