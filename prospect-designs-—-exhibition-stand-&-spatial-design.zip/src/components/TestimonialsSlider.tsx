import { useState } from 'react';
import { ArrowLeft, ArrowRight, Quote } from 'lucide-react';
import { TESTIMONIALS, UI_COPY, type LanguageCode } from '../data/content';

interface TestimonialsSliderProps {
  language: LanguageCode;
}

export function TestimonialsSlider({ language }: TestimonialsSliderProps) {
  const [activeIdx, setActiveIdx] = useState(0);
  const copy = UI_COPY[language].sections;
  const current = TESTIMONIALS[activeIdx];

  const handlePrev = () => {
    setActiveIdx((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const handleNext = () => {
    setActiveIdx((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  return (
    <section
      aria-labelledby="testimonials-heading"
      className="py-20 sm:py-24 lg:py-28 bg-[#FAFAFA]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left column: Heading + Controls */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
                {copy.testimonialsEyebrow}
              </p>
              <h2
                id="testimonials-heading"
                className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#0E0E0E] leading-[1.14] mb-6"
              >
                {copy.testimonialsTitle}
              </h2>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handlePrev}
                aria-label="Previous client testimonial"
                className="h-11 w-11 rounded-xl border border-neutral-300 bg-white text-[#0E0E0E] hover:border-[#EA4C18] hover:text-[#EA4C18] inline-flex items-center justify-center transition-colors cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={handleNext}
                aria-label="Next client testimonial"
                className="h-11 w-11 rounded-xl border border-neutral-300 bg-white text-[#0E0E0E] hover:border-[#EA4C18] hover:text-[#EA4C18] inline-flex items-center justify-center transition-colors cursor-pointer"
              >
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
              <span className="ml-2 text-xs font-medium text-neutral-500 tabular-nums">
                {String(activeIdx + 1).padStart(2, '0')} /{' '}
                {String(TESTIMONIALS.length).padStart(2, '0')}
              </span>
            </div>
          </div>

          {/* Right column: Active Testimonial Card */}
          <div className="lg:col-span-8">
            <figure
              aria-live="polite"
              className="rounded-2xl bg-white border border-neutral-200/80 p-7 sm:p-10"
            >
              <Quote className="h-8 w-8 text-[#EA4C18]/30 mb-5" aria-hidden="true" />

              <blockquote className="text-lg sm:text-2xl font-medium text-[#0E0E0E] leading-relaxed tracking-tight mb-8">
                “{current.quote}”
              </blockquote>

              <figcaption className="pt-6 border-t border-neutral-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <p className="text-base font-semibold text-[#0E0E0E]">{current.author}</p>
                  <p className="text-sm text-neutral-500">
                    {current.role} · {current.company} ·{' '}
                    <span className="text-neutral-700 font-medium">{current.industry}</span>
                  </p>
                </div>
                <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] shrink-0">
                  {current.outcome}
                </p>
              </figcaption>
            </figure>

            {/* Direct Slide Selectors */}
            <div
              role="tablist"
              aria-label="Choose testimonial"
              className="mt-5 flex flex-wrap items-center gap-2"
            >
              {TESTIMONIALS.map((item, idx) => {
                const isSelected = idx === activeIdx;
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setActiveIdx(idx)}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#0E0E0E] text-white'
                        : 'text-neutral-500 hover:text-[#0E0E0E] hover:bg-neutral-200/60'
                    }`}
                  >
                    {item.company}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
