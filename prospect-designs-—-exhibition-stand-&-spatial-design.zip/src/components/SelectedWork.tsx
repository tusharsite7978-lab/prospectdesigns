import { ArrowUpRight } from 'lucide-react';
import {
  PROJECTS,
  UI_COPY,
  type LanguageCode,
  type ProjectCaseStudy,
  type ProjectCategory,
} from '../data/content';
import { filterProjects, getCategoryCounts } from '../utils/enquiry';
import { ResilientImage } from './ResilientImage';
import { Reveal } from './Reveal';

interface SelectedWorkProps {
  language: LanguageCode;
  activeCategory: ProjectCategory;
  onCategoryChange: (cat: ProjectCategory) => void;
  onSelectProject: (project: ProjectCaseStudy) => void;
}

const CATEGORIES: ProjectCategory[] = ['All', 'Exhibition', 'Event', 'Interior', 'Activation'];

export function SelectedWork({
  language,
  activeCategory,
  onCategoryChange,
  onSelectProject,
}: SelectedWorkProps) {
  const copy = UI_COPY[language].sections;
  const filteredProjects = filterProjects(PROJECTS, activeCategory);
  const counts = getCategoryCounts(PROJECTS);

  return (
    <section
      id="work"
      aria-labelledby="selected-work-heading"
      className="py-20 sm:py-24 lg:py-28 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header + Category Filter Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-12 lg:mb-14">
          <div className="lg:col-span-7">
            <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
              {copy.workEyebrow}
            </p>
            <h2
              id="selected-work-heading"
              className="text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold tracking-tight text-[#0E0E0E] leading-[1.12] mb-4"
            >
              {copy.workTitle}
            </h2>
            <p className="text-base text-neutral-600 max-w-2xl leading-relaxed">
              {copy.workSub}
            </p>
          </div>

          <div className="lg:col-span-5 flex lg:justify-end">
            <div
              role="tablist"
              aria-label="Filter projects by category"
              className="inline-flex flex-wrap items-center gap-1 p-1 bg-[#FAFAFA] border border-neutral-200/90 rounded-xl"
            >
              {CATEGORIES.map((category) => {
                const isActive = activeCategory === category;
                return (
                  <button
                    key={category}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => onCategoryChange(category)}
                    className={`min-h-[40px] px-3.5 py-2 text-xs sm:text-[13px] font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18] ${
                      isActive
                        ? 'bg-[#0E0E0E] text-white'
                        : 'text-neutral-600 hover:text-[#0E0E0E] hover:bg-neutral-200/60'
                    }`}
                  >
                    {category}{' '}
                    <span
                      className={`ml-1 tabular-nums text-[11px] ${
                        isActive ? 'text-white/70' : 'text-neutral-400'
                      }`}
                    >
                      {counts[category]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Portfolio-First Bento Grid */}
        <div
          data-testid="projects-grid"
          className="grid grid-cols-1 md:grid-cols-12 gap-6 lg:gap-7"
        >
          {filteredProjects.map((project, index) => {
            // Dynamic architectural bento spans when showing full showcase
            const isWideCard =
              activeCategory === 'All' && project.featuredSpan === 'wide';
            const colSpanClass = isWideCard ? 'md:col-span-7' : 'md:col-span-5';
            const balancedSpanClass =
              activeCategory !== 'All'
                ? filteredProjects.length === 1
                  ? 'md:col-span-12'
                  : 'md:col-span-6'
                : index === 0
                  ? 'md:col-span-7'
                  : index === 1
                    ? 'md:col-span-5'
                    : index === 2
                      ? 'md:col-span-4'
                      : index === 3
                        ? 'md:col-span-4'
                        : index === 4
                          ? 'md:col-span-4'
                          : colSpanClass === 'md:col-span-7'
                            ? 'md:col-span-12'
                            : 'md:col-span-6';

            const aspectClass =
              balancedSpanClass === 'md:col-span-12'
                ? 'aspect-[16/9] lg:aspect-[21/9]'
                : activeCategory === 'All' && (index === 0 || index === 1)
                  ? 'aspect-[16/10] md:aspect-auto md:h-[380px] lg:h-[430px]'
                  : 'aspect-[4/3]';

            return (
              <Reveal key={project.slug} className={balancedSpanClass}>
                <article className="group h-full">
                  <button
                    type="button"
                    onClick={() => onSelectProject(project)}
                    aria-label={`View case study: ${project.title} for ${project.client}`}
                    className="w-full h-full text-left flex flex-col cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#EA4C18] rounded-2xl"
                  >
                    {/* Large Edge-to-Edge Project Photograph */}
                    <div
                      className={`relative w-full overflow-hidden rounded-2xl bg-neutral-100 border border-neutral-200/70 ${aspectClass}`}
                    >
                      <ResilientImage
                        src={project.coverImage}
                        alt={project.coverAlt}
                        width={project.width}
                        height={project.height}
                        fallbackLabel={project.title}
                        className="h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03]"
                      />
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      />
                      <div
                        aria-hidden="true"
                        className="absolute bottom-4 right-4 h-10 w-10 rounded-full bg-white text-[#0E0E0E] flex items-center justify-center opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-[transform,opacity] duration-300"
                      >
                        <ArrowUpRight className="h-4 w-4" />
                      </div>
                    </div>

                    {/* Clean Unboxed Architectural Metadata Below Image */}
                    <div className="pt-4 px-1 flex flex-col gap-1">
                      <div className="flex items-center justify-between gap-3 text-xs text-neutral-500">
                        <div className="flex items-center gap-1.5 min-w-0 truncate">
                          <span className="font-semibold text-[#EA4C18] shrink-0">
                            {project.category}
                          </span>
                          <span aria-hidden="true" className="shrink-0">
                            ·
                          </span>
                          <span className="truncate">{project.client}</span>
                        </div>
                        <span className="tabular-nums text-neutral-400 shrink-0 whitespace-nowrap">
                          {project.area}
                        </span>
                      </div>

                      <h3 className="text-lg sm:text-xl font-semibold text-[#0E0E0E] tracking-tight group-hover:text-[#EA4C18] transition-colors">
                        {project.title}
                      </h3>

                      <p className="text-xs text-neutral-500">{project.location}</p>
                    </div>
                  </button>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
