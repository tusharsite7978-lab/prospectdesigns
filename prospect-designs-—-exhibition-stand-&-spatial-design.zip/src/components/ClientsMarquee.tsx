import { CLIENTS, UI_COPY, type LanguageCode } from '../data/content';

interface ClientsMarqueeProps {
  language: LanguageCode;
}

export function ClientsMarquee({ language }: ClientsMarqueeProps) {
  const copy = UI_COPY[language].sections;
  // Duplicate array once for seamless 50% CSS translate3d loop
  const loopedClients = [...CLIENTS, ...CLIENTS];

  return (
    <section
      aria-label="Selected B2B clients"
      className="py-16 sm:py-20 bg-white border-b border-neutral-200/70 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <p className="text-xs sm:text-sm font-medium text-neutral-500 text-center">
          {copy.clientsEyebrow}
        </p>
      </div>

      <div className="relative">
        {/* Soft edge fade masks */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 left-0 w-16 sm:w-28 z-10 bg-gradient-to-r from-white to-transparent"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 right-0 w-16 sm:w-28 z-10 bg-gradient-to-l from-white to-transparent"
        />

        <div className="animate-marquee flex items-center gap-6 sm:gap-8">
          {loopedClients.map((client, idx) => (
            <div
              key={`${client.name}-${idx}`}
              className="group flex items-center gap-3.5 px-6 py-4 rounded-2xl border border-neutral-200/80 bg-[#FAFAFA] hover:bg-white hover:border-neutral-300 transition-colors shrink-0 select-none"
            >
              <span
                className="h-9 w-9 rounded-lg flex items-center justify-center text-xs font-bold tracking-tight bg-neutral-200/80 text-neutral-600 grayscale group-hover:grayscale-0 group-hover:bg-[#EA4C18] group-hover:text-white transition-[background-color,color,filter] duration-200"
                aria-hidden="true"
              >
                {client.monogram}
              </span>
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-neutral-700 group-hover:text-[#0E0E0E] transition-colors whitespace-nowrap">
                  {client.name}
                </span>
                <span className="text-[11px] text-neutral-400 group-hover:text-[#EA4C18] transition-colors whitespace-nowrap">
                  {client.sector}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
