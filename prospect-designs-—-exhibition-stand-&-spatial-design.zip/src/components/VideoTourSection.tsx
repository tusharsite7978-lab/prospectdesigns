import { useState } from 'react';
import { ExternalLink, Play } from 'lucide-react';
import {
  CONTACT_INFO,
  MEDIA_ASSETS,
  UI_COPY,
  type LanguageCode,
} from '../data/content';
import { ResilientImage } from './ResilientImage';
import { Reveal } from './Reveal';

interface VideoTourSectionProps {
  language: LanguageCode;
}

/**
 * Click-to-play YouTube facade (ID: 4BiXSeJWOcI).
 * Loads zero YouTube iframe bytes until the visitor explicitly clicks Play.
 */
export function VideoTourSection({ language }: VideoTourSectionProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const copy = UI_COPY[language].sections;
  const videoId = CONTACT_INFO.youtubeTourId;

  return (
    <section
      aria-labelledby="video-tour-heading"
      className="py-20 sm:py-24 lg:py-28 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
              {copy.videoEyebrow}
            </p>
            <h2
              id="video-tour-heading"
              className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#0E0E0E] leading-[1.12]"
            >
              {copy.videoTitle}
            </h2>
          </div>

          <a
            href={CONTACT_INFO.youtubeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm font-semibold text-neutral-700 hover:text-[#EA4C18] transition-colors whitespace-nowrap shrink-0"
          >
            <span>YouTube {CONTACT_INFO.youtubeHandle}</span>
            <ExternalLink className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>

        <Reveal>
          <div className="relative overflow-hidden rounded-2xl bg-[#0E0E0E] border border-neutral-200/80 aspect-video">
            {isPlaying ? (
              <iframe
                title="Prospect Designs Exhibition Stand Tour"
                src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="h-full w-full border-0"
              />
            ) : (
              <button
                type="button"
                onClick={() => setIsPlaying(true)}
                aria-label="Play Prospect Designs exhibition stand video tour"
                className="group relative block h-full w-full text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#EA4C18]"
              >
                <ResilientImage
                  src={MEDIA_ASSETS.heroPoster}
                  alt="Video tour preview of custom B2B exhibition stands fabricated by Prospect Designs"
                  width={1600}
                  height={900}
                  fallbackLabel="Prospect Designs Video Tour"
                  className="h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03]"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-black/15"
                />

                {/* Centered Play Trigger */}
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <span className="h-16 w-16 sm:h-20 sm:w-20 rounded-full bg-[#EA4C18] text-white flex items-center justify-center transition-transform duration-200 group-hover:scale-105">
                    <Play className="h-7 w-7 sm:h-8 sm:w-8 fill-white ml-1" aria-hidden="true" />
                  </span>
                  <span className="mt-4 text-sm sm:text-base font-semibold text-white">
                    Play Exhibition Showreel &amp; Build Tour
                  </span>
                  <span className="mt-1 text-xs text-white/75">
                    Click to stream YouTube walkthrough · Zero background autoplay
                  </span>
                </div>
              </button>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
