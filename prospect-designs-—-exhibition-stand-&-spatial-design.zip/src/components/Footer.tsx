import { ArrowUpRight, Linkedin, Youtube } from 'lucide-react';
import { CONTACT_INFO, MEDIA_ASSETS } from '../data/content';

interface FooterProps {
  onNavigateHome: (sectionId?: string) => void;
}

export function Footer({ onNavigateHome }: FooterProps) {
  const quickLinks = [
    { label: 'Selected Work', target: 'work' },
    { label: 'Exhibition Stalls', target: 'exhibition' },
    { label: 'Events Organisation', target: 'events' },
    { label: 'Spaces & Activation', target: 'spaces' },
    { label: 'Interior Designing', target: 'interiors' },
    { label: 'Process', target: 'process' },
    { label: 'FAQ', target: 'faq' },
    { label: 'Contact', target: 'contact' },
  ];

  return (
    <footer className="bg-[#0E0E0E] text-white border-t border-neutral-800 pb-20 md:pb-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12 pb-12 border-b border-white/10">
          {/* Brand Summary */}
          <div className="md:col-span-5">
            <a
              href="#top"
              onClick={(e) => {
                e.preventDefault();
                onNavigateHome();
              }}
              aria-label="Prospect Designs — Back to top"
              className="inline-flex items-center bg-white rounded-xl px-3.5 py-2 mb-5"
            >
              <img
                src={MEDIA_ASSETS.logo}
                alt="Prospect Designs"
                width={150}
                height={42}
                loading="lazy"
                className="h-9 w-auto object-contain"
              />
            </a>
            <p className="text-base font-medium text-white mb-2">
              {CONTACT_INFO.tagline}
            </p>
            <p className="text-sm text-neutral-400 leading-relaxed max-w-sm mb-6">
              360° exhibition stand design, corporate event production, brand activations, and
              commercial interiors from Pune to India, Germany, and Dubai.
            </p>

            <div className="flex items-center gap-3">
              <a
                href={CONTACT_INFO.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Prospect Designs on LinkedIn"
                className="inline-flex items-center gap-2 min-h-[40px] px-3.5 rounded-lg border border-white/15 text-xs font-semibold text-white/90 hover:border-[#EA4C18] hover:text-white transition-colors"
              >
                <Linkedin className="h-4 w-4 text-[#EA4C18]" aria-hidden="true" />
                <span>LinkedIn</span>
              </a>
              <a
                href={CONTACT_INFO.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Prospect Designs on YouTube"
                className="inline-flex items-center gap-2 min-h-[40px] px-3.5 rounded-lg border border-white/15 text-xs font-semibold text-white/90 hover:border-[#EA4C18] hover:text-white transition-colors"
              >
                <Youtube className="h-4 w-4 text-[#EA4C18]" aria-hidden="true" />
                <span>YouTube</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3">
            <h2 className="text-xs font-semibold text-neutral-400 mb-4">Quick Links</h2>
            <ul className="grid grid-cols-2 md:grid-cols-1 gap-y-2.5 gap-x-4 text-sm text-neutral-300">
              {quickLinks.map((link) => (
                <li key={link.target}>
                  <a
                    href={`#${link.target}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigateHome(link.target);
                    }}
                    className="hover:text-[#EA4C18] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Contact Details */}
          <div className="md:col-span-4">
            <h2 className="text-xs font-semibold text-neutral-400 mb-4">Contact</h2>
            <address className="not-italic space-y-3 text-sm text-neutral-300">
              <p className="font-semibold text-white">{CONTACT_INFO.companyLegal}</p>
              <p className="text-neutral-400 leading-relaxed">{CONTACT_INFO.address}</p>

              <div className="pt-1 flex flex-col gap-1 tabular-nums">
                {CONTACT_INFO.phones.map((phone) => (
                  <a
                    key={phone.href}
                    href={phone.href}
                    className="hover:text-[#EA4C18] transition-colors w-fit"
                  >
                    {phone.display}
                  </a>
                ))}
              </div>

              <div className="pt-1 flex flex-col gap-1">
                {CONTACT_INFO.emails.map((email) => (
                  <a
                    key={email.href}
                    href={email.href}
                    className="hover:text-[#EA4C18] transition-colors w-fit"
                  >
                    {email.display}
                  </a>
                ))}
              </div>

              <div className="pt-2">
                <a
                  href={CONTACT_INFO.whatsappBaseUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#EA4C18] hover:text-white transition-colors"
                >
                  <span>Chat on WhatsApp</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </address>
          </div>
        </div>

        {/* Bottom Quiet Legal Line */}
        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-neutral-500">
          <p>
            © {new Date().getFullYear()} {CONTACT_INFO.companyLegal}. All rights reserved.
          </p>
          <p>Pune · India · Germany · Dubai</p>
        </div>
      </div>
    </footer>
  );
}
