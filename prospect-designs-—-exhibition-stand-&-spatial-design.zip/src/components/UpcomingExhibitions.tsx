import { ArrowUpRight, Calendar, MapPin } from 'lucide-react';
import {
  UI_COPY,
  UPCOMING_EXHIBITIONS,
  type LanguageCode,
  type UpcomingExhibition,
} from '../data/content';
import { Reveal } from './Reveal';

interface UpcomingExhibitionsProps {
  language: LanguageCode;
  onReserveExhibition: (exhibition: UpcomingExhibition) => void;
}

export function UpcomingExhibitions({
  language,
  onReserveExhibition,
}: UpcomingExhibitionsProps) {
  const copy = UI_COPY[language].sections;

  return (
    <section
      aria-labelledby="upcoming-heading"
      className="py-20 sm:py-24 bg-[#FAFAFA] border-y border-neutral-200/70"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
            {copy.upcomingEyebrow}
          </p>
          <h2
            id="upcoming-heading"
            className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#0E0E0E] leading-[1.12]"
          >
            {copy.upcomingTitle}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {UPCOMING_EXHIBITIONS.map((expo) => (
            <Reveal key={expo.id}>
              <div className="h-full rounded-2xl bg-white border border-neutral-200/80 p-6 flex flex-col justify-between">
                <div>
                  <p className="text-xs font-semibold text-[#EA4C18] mb-2">
                    {expo.country} · {expo.slotsOpen}
                  </p>
                  <h3 className="text-lg font-semibold text-[#0E0E0E] mb-1.5">
                    {expo.name}
                  </h3>
                  <p className="text-xs text-neutral-500 mb-5">{expo.sector}</p>

                  <div className="space-y-2 text-xs sm:text-sm text-neutral-600 mb-6">
                    <p className="flex items-center gap-2 tabular-nums">
                      <Calendar className="h-4 w-4 text-neutral-400 shrink-0" aria-hidden="true" />
                      <span>{expo.dates}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-neutral-400 shrink-0" aria-hidden="true" />
                      <span>{expo.city}</span>
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onReserveExhibition(expo)}
                  className="w-full min-h-[42px] px-4 py-2.5 rounded-xl border border-neutral-200 hover:border-[#0E0E0E] hover:bg-[#0E0E0E] hover:text-white text-[#0E0E0E] text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>Book Stall Design</span>
                  <ArrowUpRight className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
