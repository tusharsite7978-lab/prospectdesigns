import { useState } from 'react';
import { Globe, Menu, X } from 'lucide-react';
import {
  CONTACT_INFO,
  MEDIA_ASSETS,
  UI_COPY,
  type LanguageCode,
} from '../data/content';

interface HeaderProps {
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onNavigateHome: (sectionId?: string) => void;
  onRequestQuote: (requirement?: string) => void;
  isCaseStudyOpen: boolean;
}

const LANGUAGES: { code: LanguageCode; label: string; fullName: string }[] = [
  { code: 'en', label: 'EN', fullName: 'English' },
  { code: 'hi', label: 'HI', fullName: 'Hindi' },
  { code: 'mr', label: 'MR', fullName: 'Marathi' },
];

export function Header({
  language,
  onLanguageChange,
  onNavigateHome,
  onRequestQuote,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const copy = UI_COPY[language].nav;

  const navItems = [
    { label: copy.exhibition, target: 'exhibition' },
    { label: copy.events, target: 'events' },
    { label: copy.spaces, target: 'spaces' },
    { label: copy.interiors, target: 'interiors' },
    { label: copy.projects, target: 'work' },
    { label: copy.about, target: 'about' },
    { label: copy.contact, target: 'contact' },
  ];

  const handleLinkClick = (target: string) => {
    setMobileMenuOpen(false);
    onNavigateHome(target);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 lg:h-[72px] flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Mark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setMobileMenuOpen(false);
            onNavigateHome();
          }}
          aria-label="Prospect Designs — Home"
          className="flex items-center shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#EA4C18] rounded-md"
        >
          <img
            src={MEDIA_ASSETS.logo}
            alt="Prospect Designs"
            width={180}
            height={48}
            loading="eager"
            decoding="sync"
            className="h-10 sm:h-11 lg:h-12 w-auto object-contain"
          />
        </a>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden xl:flex items-center gap-6 text-[13px] font-medium text-neutral-700"
        >
          {navItems.map((item) => (
            <a
              key={item.target}
              href={`#${item.target}`}
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick(item.target);
              }}
              className="relative py-1 whitespace-nowrap shrink-0 hover:text-[#0E0E0E] transition-colors after:content-[''] after:absolute after:left-0 after:bottom-0 after:h-[1.5px] after:w-full after:origin-left after:scale-x-0 after:bg-[#EA4C18] after:transition-transform after:duration-200 hover:after:scale-x-100 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#EA4C18]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Language Switcher + Primary Quote CTA + Mobile Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden sm:flex items-center gap-1 border border-neutral-200 rounded-lg px-2 py-1 text-xs text-neutral-600">
            <Globe className="h-3.5 w-3.5 text-neutral-400 shrink-0" aria-hidden="true" />
            <label htmlFor="desktop-lang-select" className="sr-only">
              Select language
            </label>
            <select
              id="desktop-lang-select"
              value={language}
              onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
              aria-label="Language switcher"
              className="bg-transparent font-medium text-neutral-800 focus:outline-none cursor-pointer pr-1"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              onRequestQuote();
            }}
            className="inline-flex items-center justify-center px-4 sm:px-5 py-2.5 text-xs sm:text-[13px] font-semibold text-white bg-[#EA4C18] hover:bg-[#D23E0E] active:scale-[0.98] rounded-xl transition-[transform,background-color] duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18]"
          >
            {copy.getQuote}
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-nav-drawer"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="xl:hidden inline-flex items-center justify-center h-11 w-11 rounded-xl border border-neutral-200 text-neutral-800 hover:bg-neutral-50 transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile / Tablet Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="xl:hidden border-t border-neutral-200 bg-white px-4 sm:px-6 py-5"
        >
          <nav aria-label="Mobile navigation" className="grid grid-cols-2 gap-1.5 mb-5">
            {navItems.map((item) => (
              <a
                key={item.target}
                href={`#${item.target}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(item.target);
                }}
                className="flex items-center min-h-[44px] px-3 rounded-lg text-sm font-medium text-neutral-800 hover:bg-neutral-50 hover:text-[#EA4C18] transition-colors"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-neutral-100">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-neutral-500 mr-1">Language:</span>
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => onLanguageChange(lang.code)}
                  aria-label={`Switch language to ${lang.fullName}`}
                  aria-pressed={language === lang.code}
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    language === lang.code
                      ? 'bg-[#0E0E0E] text-white'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
            <a
              href={CONTACT_INFO.phones[0].href}
              className="text-xs font-semibold text-neutral-700 hover:text-[#EA4C18] tabular-nums"
            >
              {CONTACT_INFO.phones[0].display}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
