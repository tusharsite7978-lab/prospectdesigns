import { useEffect, useRef, useState } from 'react';
import {
  Clock,
  Compass,
  MessageSquare,
  ShieldCheck,
  Target,
  Wallet,
} from 'lucide-react';
import {
  STATS,
  UI_COPY,
  WHY_PROSPECT,
  type LanguageCode,
  type StatItem,
  type WhyProspectItem,
} from '../data/content';
import { Reveal } from './Reveal';

interface WhyProspectSectionProps {
  language: LanguageCode;
}

function FeatureIcon({ icon }: { icon: WhyProspectItem['icon'] }) {
  const cls = 'h-5 w-5 text-[#EA4C18] shrink-0';
  switch (icon) {
    case 'compass':
      return <Compass className={cls} aria-hidden="true" />;
    case 'shield':
      return <ShieldCheck className={cls} aria-hidden="true" />;
    case 'message':
      return <MessageSquare className={cls} aria-hidden="true" />;
    case 'target':
      return <Target className={cls} aria-hidden="true" />;
    case 'clock':
      return <Clock className={cls} aria-hidden="true" />;
    case 'wallet':
      return <Wallet className={cls} aria-hidden="true" />;
  }
}

function AnimatedStat({ stat, active }: { stat: StatItem; active: boolean }) {
  const [displayVal, setDisplayVal] = useState(stat.value);

  useEffect(() => {
    if (!active) return;

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      setDisplayVal(stat.value);
      return;
    }

    let rafId = 0;
    const duration = 900;
    const start = performance.now();

    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayVal(Math.max(1, Math.round(eased * stat.value)));
      if (progress < 1) {
        rafId = requestAnimationFrame(tick);
      } else {
        setDisplayVal(stat.value);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [active, stat.value]);

  return (
    <div className="flex flex-col">
      <p className="text-4xl sm:text-5xl font-semibold tracking-tight text-white tabular-nums mb-2">
        {displayVal}
        <span className="text-[#EA4C18]">{stat.suffix}</span>
      </p>
      <p className="text-sm sm:text-base font-semibold text-white mb-1">{stat.label}</p>
      <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">{stat.detail}</p>
    </div>
  );
}

export function WhyProspectSection({ language }: WhyProspectSectionProps) {
  const copy = UI_COPY[language].sections;
  const statsRef = useRef<HTMLDivElement | null>(null);
  const [statsTriggered, setStatsTriggered] = useState(false);

  useEffect(() => {
    const el = statsRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setStatsTriggered(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setStatsTriggered(true);
            observer.unobserve(el);
          }
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" aria-labelledby="why-prospect-heading" className="bg-[#FAFAFA]">
      {/* 6 Compact Icon Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24 lg:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-14">
          <div className="lg:col-span-7">
            <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
              {copy.whyEyebrow}
            </p>
            <h2
              id="why-prospect-heading"
              className="text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold tracking-tight text-[#0E0E0E] leading-[1.12]"
            >
              {copy.whyTitle}
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-base text-neutral-600 leading-relaxed">
              Based in Talegaon Dabhade, Pune, we run an in-house design and fabrication studio
              focused on B2B manufacturing, pharma, electronics, textile, and die &amp; mould
              exhibitors across India, Germany, and Dubai.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {WHY_PROSPECT.map((item) => (
            <Reveal key={item.id}>
              <div className="h-full rounded-2xl bg-white border border-neutral-200/80 p-6 flex flex-col gap-3">
                <div className="h-10 w-10 rounded-xl bg-[#FFF4EF] flex items-center justify-center">
                  <FeatureIcon icon={item.icon} />
                </div>
                <h3 className="text-base sm:text-lg font-semibold text-[#0E0E0E]">
                  {item.title}
                </h3>
                <p className="text-sm text-neutral-600 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* Dedicated Dark Architectural Stats Strip */}
      <div
        ref={statsRef}
        aria-label="Prospect Designs performance metrics"
        className="bg-[#0E0E0E] border-y border-neutral-800"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16 lg:py-20">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
            {STATS.map((stat) => (
              <AnimatedStat key={stat.label} stat={stat} active={statsTriggered} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
