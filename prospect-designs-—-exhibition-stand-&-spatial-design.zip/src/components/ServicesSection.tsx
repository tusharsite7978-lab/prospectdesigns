import { ArrowRight, Check } from 'lucide-react';
import {
  SERVICES,
  UI_COPY,
  type LanguageCode,
  type ProjectCategory,
  type ServiceItem,
} from '../data/content';
import { ResilientImage } from './ResilientImage';
import { Reveal } from './Reveal';

interface ServicesSectionProps {
  language: LanguageCode;
  onExploreService: (service: ServiceItem) => void;
  onFilterByService: (category: Exclude<ProjectCategory, 'All'>) => void;
}

export function ServicesSection({
  language,
  onExploreService,
  onFilterByService,
}: ServicesSectionProps) {
  const copy = UI_COPY[language].sections;

  return (
    <section
      id="services"
      aria-labelledby="services-heading"
      className="py-20 sm:py-24 lg:py-28 bg-[#FAFAFA] border-y border-neutral-200/70"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-14 lg:mb-16">
          <p className="text-xs sm:text-sm font-semibold text-[#EA4C18] mb-3">
            {copy.servicesEyebrow}
          </p>
          <h2
            id="services-heading"
            className="text-3xl sm:text-4xl lg:text-[2.65rem] font-semibold tracking-tight text-[#0E0E0E] leading-[1.12]"
          >
            {copy.servicesTitle}
          </h2>
        </div>

        {/* 4 Large Alternating Architectural Service Cards */}
        <div className="space-y-12 lg:space-y-20">
          {SERVICES.map((service, idx) => {
            const isReversed = idx % 2 === 1;
            return (
              <Reveal key={service.id}>
                <div
                  id={service.navAnchor}
                  className="scroll-mt-24 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch bg-white rounded-2xl border border-neutral-200/80 p-5 sm:p-7 lg:p-8"
                >
                  {/* Visual Column */}
                  <div
                    className={`lg:col-span-6 overflow-hidden rounded-xl bg-neutral-100 aspect-[4/3] lg:aspect-auto ${
                      isReversed ? 'lg:order-2' : 'lg:order-1'
                    }`}
                  >
                    <ResilientImage
                      src={service.image}
                      alt={service.imageAlt}
                      width={1400}
                      height={1050}
                      fallbackLabel={service.title}
                      className="h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] hover:scale-[1.03]"
                    />
                  </div>

                  {/* Editorial Detail Column */}
                  <div
                    className={`lg:col-span-6 flex flex-col justify-between py-1 sm:py-2 ${
                      isReversed ? 'lg:order-1' : 'lg:order-2'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-semibold text-neutral-400 tabular-nums mb-2">
                        {service.number}. Service Vertical
                      </p>
                      <h3 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#0E0E0E] mb-3">
                        {service.title}
                      </h3>
                      <p className="text-base text-neutral-600 leading-relaxed mb-6">
                        {service.subtitle}
                      </p>

                      <ul className="space-y-3 mb-8">
                        {service.bullets.map((bullet) => (
                          <li
                            key={bullet}
                            className="flex items-start gap-3 text-sm sm:text-[15px] text-neutral-700 leading-snug"
                          >
                            <Check
                              className="h-4 w-4 text-[#EA4C18] shrink-0 mt-0.5"
                              aria-hidden="true"
                            />
                            <span>{bullet}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-neutral-100">
                      <button
                        type="button"
                        onClick={() => onExploreService(service)}
                        className="inline-flex items-center gap-2 min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0E0E0E] hover:bg-[#EA4C18] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#EA4C18]"
                      >
                        <span>Know More</span>
                        <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onFilterByService(service.categoryFilter)}
                        className="inline-flex items-center min-h-[44px] px-2 text-sm font-semibold text-neutral-600 hover:text-[#EA4C18] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        View {service.categoryFilter} projects
                      </button>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
